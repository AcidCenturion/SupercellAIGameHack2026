// Bridge to connect game code to Rosebud AI image generation
// This provides the window.generateImages API that the game expects

(function() {
    'use strict';
    
    // Store generated images cache to avoid regenerating
    const imageCache = new Map();
    
    /**
     * Generate images using Rosebud AI backend
     * @param {Array} requests - Array of {prompt: string, num_images: number} objects
     * @returns {Promise<Array<string>>} - Array of image URLs
     */
    async function generateImages(requests) {
        console.log('[ImageGeneratorBridge] generateImages called with requests:', requests);
        
        if (!Array.isArray(requests) || requests.length === 0) {
            console.error('[ImageGeneratorBridge] Invalid requests:', requests);
            return [];
        }
        
        const results = [];
        
        for (const request of requests) {
            const { prompt, num_images = 1 } = request;
            
            if (!prompt) {
                console.warn('[ImageGeneratorBridge] Skipping request with no prompt');
                results.push(null);
                continue;
            }
            
            // Check cache first
            const cacheKey = `${prompt}_${num_images}`;
            if (imageCache.has(cacheKey)) {
                console.log('[ImageGeneratorBridge] Returning cached image for prompt');
                results.push(imageCache.get(cacheKey));
                continue;
            }
            
            try {
                console.log('[ImageGeneratorBridge] Generating image for prompt:', prompt);
                
                // Call the Rosebud platform's image generation
                // This needs to interface with the backend through a message passing system
                const imageUrl = await requestImageGeneration(prompt);
                
                if (imageUrl) {
                    console.log('[ImageGeneratorBridge] Successfully generated image:', imageUrl);
                    imageCache.set(cacheKey, imageUrl);
                    results.push(imageUrl);
                } else {
                    console.warn('[ImageGeneratorBridge] No image URL returned for prompt:', prompt);
                    results.push(null);
                }
                
            } catch (error) {
                console.error('[ImageGeneratorBridge] Error generating image:', error);
                results.push(null);
            }
        }
        
        return results;
    }
    
    /**
     * Helper to extract URL from various result formats
     */
    function extractUrlFromResult(result) {
        if (!result) return null;
        if (typeof result === 'string') return result;
        return result.url || result.imageUrl || result.src || result.href || null;
    }
    
    /**
     * Pre-generated fusion images lookup table
     * All 24 creature + element combinations (6 creatures × 4 elements)
     */
    const fusionAssets = {
        // Blazing Scarf fusions
        'blazing_scarf_fire': 'https://rosebud.ai/assets/fusion_blazing_scarf_fire.webp?zrxe',
        'blazing_scarf_water': 'https://rosebud.ai/assets/fusion_blazing_scarf_water.webp?p40K',
        'blazing_scarf_stone': 'https://rosebud.ai/assets/fusion_blazing_scarf_stone.webp?cSWW',
        'blazing_scarf_wood': 'https://rosebud.ai/assets/fusion_blazing_scarf_wood.webp?doth',
        
        // Planted Pot fusions
        'planted_pot_fire': 'https://rosebud.ai/assets/fusion_planted_pot_fire.webp?JxF4',
        'planted_pot_water': 'https://rosebud.ai/assets/fusion_planted_pot_water.webp?RMHJ',
        'planted_pot_stone': 'https://rosebud.ai/assets/fusion_planted_pot_stone.webp?3VnK',
        'planted_pot_wood': 'https://rosebud.ai/assets/fusion_planted_pot_wood.webp?4M0d',
        
        // Rock Gem fusions
        'rock_gem_fire': 'https://rosebud.ai/assets/fusion_rock_gem_fire.webp?sC0a',
        'rock_gem_water': 'https://rosebud.ai/assets/fusion_rock_gem_water.webp?OBZV',
        'rock_gem_stone': 'https://rosebud.ai/assets/fusion_rock_gem_stone.webp?LH68',
        'rock_gem_wood': 'https://rosebud.ai/assets/fusion_rock_gem_wood.webp?CV1e',
        
        // Painguin fusions
        'painguin_fire': 'https://rosebud.ai/assets/fusion_painguin_fire.webp?hIXP',
        'painguin_water': 'https://rosebud.ai/assets/fusion_painguin_water.webp?OlbF',
        'painguin_stone': 'https://rosebud.ai/assets/fusion_painguin_stone.webp?Vtrj',
        'painguin_wood': 'https://rosebud.ai/assets/fusion_painguin_wood.webp?UW94',
        
        // Bicosis fusions
        'bicosis_fire': 'https://rosebud.ai/assets/fusion_bicosis_fire.webp?K24g',
        'bicosis_water': 'https://rosebud.ai/assets/fusion_bicosis_water.webp?KkfS',
        'bicosis_stone': 'https://rosebud.ai/assets/fusion_bicosis_stone.webp?vMdX',
        'bicosis_wood': 'https://rosebud.ai/assets/fusion_bicosis_wood.webp?G7pT',
        
        // Shoutout fusions
        'shoutout_fire': 'https://rosebud.ai/assets/fusion_shoutout_fire.webp?zjru',
        'shoutout_water': 'https://rosebud.ai/assets/fusion_shoutout_water.webp?KZW8',
        'shoutout_stone': 'https://rosebud.ai/assets/fusion_shoutout_stone.webp?BFSW',
        'shoutout_wood': 'https://rosebud.ai/assets/fusion_shoutout_wood.webp?pqwt'
    };
    
    /**
     * Request image generation - returns pre-generated fusion assets
     * Runtime generation is not available in the Rosebud platform for gameplay
     */
    async function requestImageGeneration(prompt) {
        console.log('[ImageGeneratorBridge] Looking up fusion image for prompt:', prompt);
        
        const creatureMatch = prompt.toLowerCase().match(/blazing scarf|planted pot|rock gem|painguin|bicosis|shoutout/);
        const elementMatch = prompt.toLowerCase().match(/fire|water|stone|wood/);
        
        if (creatureMatch && elementMatch) {
            const creatureName = creatureMatch[0].replace(/ /g, '_');
            const elementName = elementMatch[0];
            const key = `${creatureName}_${elementName}`;
            
            console.log('[ImageGeneratorBridge] Looking up key:', key);
            
            if (fusionAssets[key]) {
                console.log('[ImageGeneratorBridge] Found pre-generated fusion:', fusionAssets[key]);
                
                // Simulate generation time (500ms) for consistency
                await new Promise(resolve => setTimeout(resolve, 500));
                
                return fusionAssets[key];
            }
        }
        
        console.warn('[ImageGeneratorBridge] No matching fusion found');
        console.warn('[ImageGeneratorBridge] Creature:', creatureMatch, 'Element:', elementMatch);
        
        return null;
    }
    
    // Expose the API on window
    window.generateImages = generateImages;
    
    console.log('[ImageGeneratorBridge] Image generation API initialized');
    console.log('[ImageGeneratorBridge] window.generateImages is now available');
    
    // Notify that the bridge is ready
    window.dispatchEvent(new CustomEvent('imageGeneratorReady', {
        detail: { version: '1.0.0' }
    }));
    
})();
