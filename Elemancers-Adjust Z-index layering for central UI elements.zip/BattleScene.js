import Phaser from 'phaser';
import { gameState } from './GameState.js';
import { CONFIG } from './config.js';
import Card from './Card.js';
import { soundManager } from './SoundManager.js';
import { FusionGenerator } from './FusionGenerator.js';

const ELEMENT_COUNTERS = {
    'fire': 'water',
    'water': 'fire',
    'wood': 'stone',
    'stone': 'wood'
};

export default class BattleScene extends Phaser.Scene {
    constructor() {
        super({ key: 'BattleScene' });
    }
    
    preload() {
        // Load UI assets
        this.load.image('ui_attack', 'https://rosebud.ai/assets/ui_attack.png?hBKz');
        this.load.image('ui_defense', 'https://rosebud.ai/assets/ui_defense.png?RI2H');
        this.load.image('ui_guide', 'https://rosebud.ai/assets/ui_guide.png?Fjjj');
    }
    
    create() {
        const { width, height } = this.cameras.main;
        
        this.currentPhase = 'ATTACKING'; // ATTACKING, DEFENDING
        this.isDiscardMode = false; // Track if in discard mode
        this.canInteractWithCards = true; // Track if player can click cards
        this.selectedCreature = null;
        this.selectedElement = null;
        this.selectedModifiers = [];
        this.selectedDiscards = []; // Cards selected for discarding
        this.selectedHealing = null; // Healing card selection
        
        this.attackingCards = null; // {creature, element, modifiers}
        this.defendingCards = null;
        
        this.enemyPlayedCards = []; // Visual display of enemy cards
        this.playerPlayedCards = []; // Visual display of player cards
        
        this.turnCount = 0; // Track number of turns
        
        this.setupUI();
        this.displayHands();
        
        // Player starts - they can act
        this.setTurnHue(true);
        
        // Show discard button at start
        this.updateActionButton();
    }
    
    setupUI() {
        const { width, height } = this.cameras.main;
        
        // HP displays - fighting game style with quarter circles and thick bars extending to center
        const hpQuarterCircleRadius = 105;
        const hpBarHeight = 75; // Increased by 50% (was 50)
        const hpBarY = 0; // At very top of screen so bars are hidden under circles
        const barEdgeOffset = 30; // Keep bars from going too far into circle, but edges still covered
        
        // Player HP (left side) - quarter circle in top-left corner
        const playerQuarterCircleX = 0;
        const playerQuarterCircleY = 0;
        const playerBarStartX = barEdgeOffset; // Start offset from edge
        const playerBarEndX = width / 2; // Extend to center to touch turn counter semicircle
        const playerBarWidth = playerBarEndX - playerBarStartX;
        
        // Player quarter circle background (top-left corner)
        this.playerHPQuarterCircle = this.add.circle(
            playerQuarterCircleX, 
            playerQuarterCircleY, 
            hpQuarterCircleRadius, 
            0x00aa00
        );
        this.playerHPQuarterCircle.setStrokeStyle(4, 0x00ff00);
        
        // Mask to show only bottom-right quarter
        const playerMask = this.make.graphics();
        playerMask.fillStyle(0xffffff);
        playerMask.fillRect(0, 0, hpQuarterCircleRadius, hpQuarterCircleRadius);
        this.playerHPQuarterCircle.setMask(playerMask.createGeometryMask());
        
        // Player HP bar background (extends from quarter circle to center)
        this.playerHPBarBg = this.add.rectangle(
            playerBarEndX,
            hpBarY,
            playerBarWidth,
            hpBarHeight,
            0x333333
        ).setOrigin(1, 0.5).setDepth(-1);
        
        // Player HP ghost bar (yellow, shows previous HP before damage - starts same as HP bar)
        // Must be created BEFORE the main HP bar so it appears behind
        // Anchored at center (right side), extends toward quarter circle (left)
        const playerHPPercent = gameState.playerHP / CONFIG.playerHP;
        this.playerHPGhostBar = this.add.rectangle(
            playerBarEndX,
            hpBarY,
            playerBarWidth * playerHPPercent,
            hpBarHeight,
            0xffff00
        ).setOrigin(1, 0.5).setDepth(-1);
        
        // Player HP bar (anchored at center, depletes from right to left toward quarter circle)
        this.playerHPBar = this.add.rectangle(
            playerBarEndX,
            hpBarY,
            playerBarWidth * playerHPPercent,
            hpBarHeight,
            0x00ff00
        ).setOrigin(1, 0.5).setDepth(-1);
        
        // Player HP number inside quarter circle (closer to corner)
        this.playerHPNumber = this.add.text(35, 35, `${gameState.playerHP}`, {
            fontSize: '36px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold'
        }).setOrigin(0.5, 0.5).setDepth(10); // Above HP bars
        
        // Track previous HP for comparison
        this.previousPlayerHP = gameState.playerHP;
        this.previousEnemyHP = gameState.enemyHP;
        
        // Enemy HP (right side) - quarter circle in top-right corner
        const enemyQuarterCircleX = width;
        const enemyQuarterCircleY = 0;
        const enemyBarStartX = width / 2; // Start at center to touch turn counter semicircle
        const enemyBarEndX = width - barEdgeOffset; // Offset from edge but still covered by circle
        const enemyBarWidth = enemyBarEndX - enemyBarStartX;
        
        // Enemy quarter circle background (top-right corner)
        this.enemyHPQuarterCircle = this.add.circle(
            enemyQuarterCircleX, 
            enemyQuarterCircleY, 
            hpQuarterCircleRadius, 
            0xaa0000
        );
        this.enemyHPQuarterCircle.setStrokeStyle(4, 0xff4444);
        
        // Mask to show only bottom-left quarter
        const enemyMask = this.make.graphics();
        enemyMask.fillStyle(0xffffff);
        enemyMask.fillRect(width - hpQuarterCircleRadius, 0, hpQuarterCircleRadius, hpQuarterCircleRadius);
        this.enemyHPQuarterCircle.setMask(enemyMask.createGeometryMask());
        
        // Enemy HP bar background (extends from center to quarter circle)
        this.enemyHPBarBg = this.add.rectangle(
            enemyBarStartX,
            hpBarY,
            enemyBarWidth,
            hpBarHeight,
            0x333333
        ).setOrigin(0, 0.5).setDepth(-1);
        
        // Enemy HP ghost bar (yellow, shows previous HP before damage - starts same as HP bar)
        // Must be created BEFORE the main HP bar so it appears behind
        // Anchored at center, grows to the right, so when width decreases it depletes from left to right
        const enemyHPPercent = gameState.enemyHP / CONFIG.enemyHP;
        this.enemyHPGhostBar = this.add.rectangle(
            enemyBarStartX + (enemyBarWidth * (1 - enemyHPPercent)),
            hpBarY,
            enemyBarWidth * enemyHPPercent,
            hpBarHeight,
            0xffff00
        ).setOrigin(0, 0.5).setDepth(-1);
        
        // Enemy HP bar (positioned so it appears to deplete from left to right toward corner)
        this.enemyHPBar = this.add.rectangle(
            enemyBarStartX + (enemyBarWidth * (1 - enemyHPPercent)),
            hpBarY,
            enemyBarWidth * enemyHPPercent,
            hpBarHeight,
            0xff4444
        ).setOrigin(0, 0.5).setDepth(-1);
        
        // Enemy HP number inside quarter circle (closer to corner)
        this.enemyHPNumber = this.add.text(width - 35, 35, `${gameState.enemyHP}`, {
            fontSize: '36px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold'
        }).setOrigin(0.5, 0.5).setDepth(10); // Above HP bars
        
        // Turn counter - blue semi-circle at top center
        // Make radius large enough to reach the HP bar edges (150px from center on each side)
        const turnCounterRadius = 150;
        const turnCounterY = 0;
        
        // Create semi-circle (full circle with mask showing only bottom half)
        this.turnCounterCircle = this.add.circle(
            width / 2,
            turnCounterY,
            turnCounterRadius,
            0x4444ff
        );
        this.turnCounterCircle.setStrokeStyle(4, 0x6666ff);
        this.turnCounterCircle.setDepth(20); // Top layer - above HP bars, HP numbers, and divider line
        
        // Mask to show only bottom half
        const turnCounterMask = this.make.graphics();
        turnCounterMask.fillStyle(0xffffff);
        turnCounterMask.fillRect(
            width / 2 - turnCounterRadius,
            turnCounterY,
            turnCounterRadius * 2,
            turnCounterRadius
        );
        this.turnCounterCircle.setMask(turnCounterMask.createGeometryMask());
        
        // Turn counter text (positioned towards center of semi-circle)
        this.turnCounterText = this.add.text(width / 2, turnCounterRadius / 2, `TURN ${this.turnCount}`, {
            fontSize: '32px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(20); // Top layer - same as turn counter circle
        
        // Turn indicator - colored glow at bottom of screen (behind hand and buttons)
        const bottomHueHeight = height / 3;
        
        // Create graphics for custom glow shape with rounded corners and gradient
        this.turnHueGraphics = this.add.graphics();
        this.turnHueGraphics.setDepth(-1);
        
        // Store reference for color updates
        this.turnHueColor = 0x44ff44;
        this.bottomHueHeight = bottomHueHeight;
        
        // Draw the glow shape
        this.drawTurnGlow();
        
        // Visual divider line between player and enemy card zones
        const dividerX = width / 2;
        const dividerTop = 120; // Below HP indicators
        const dividerBottom = height - bottomHueHeight; // Above the hue
        this.add.line(0, 0, dividerX, dividerTop, dividerX, dividerBottom, 0xffffff, 0.3)
            .setOrigin(0, 0)
            .setLineWidth(3)
            .setDepth(-1);
        
        // Instructions (bottom of screen) - using container for per-letter animation
        this.instructionTextBaseY = height - 25;
        this.instructionTextContainer = this.add.container(width / 2, this.instructionTextBaseY);
        this.instructionLetters = [];
        
        // Helper function to create animated instruction text
        this.createInstructionText = (message) => {
            // Clear existing letters
            this.instructionLetters.forEach(letter => letter.destroy());
            this.instructionLetters = [];
            
            // First pass: create all letters and measure total width
            const tempLetters = [];
            let totalWidth = 0;
            
            for (let i = 0; i < message.length; i++) {
                const char = message[i];
                const tempLetter = this.add.text(0, 0, char, {
                    fontSize: '24px',
                    color: '#ffffff',
                    fontFamily: 'Electrolize',
                    stroke: '#000000',
                    strokeThickness: 2
                });
                tempLetters.push(tempLetter);
                totalWidth += tempLetter.width;
            }
            
            // Second pass: position letters centered
            let currentX = -totalWidth / 2;
            for (let i = 0; i < tempLetters.length; i++) {
                const letter = tempLetters[i];
                letter.setPosition(currentX, 0);
                letter.setOrigin(0, 0.5);
                letter.letterIndex = i; // Store index for wave calculation
                
                this.instructionTextContainer.add(letter);
                this.instructionLetters.push(letter);
                
                // Move x position for next letter
                currentX += letter.width;
            }
        };
        
        // Create initial text
        this.createInstructionText('Select 1 Creature + Optional Element + Any Attack Modifiers');
        
        // Create wrapper object for backwards compatibility with setText
        this.instructionText = {
            setText: (text) => {
                this.createInstructionText(text);
            }
        };
        
        // Action button (bottom right) - for attack/defend
        this.actionButton = this.add.rectangle(width - 150, height - 80, 280, 80, 0x666666);
        this.actionButton.setStrokeStyle(4, 0xffffff);
        this.actionButton.disableInteractive();
        
        this.actionButtonText = this.add.text(width - 150, height - 80, 'SELECT CARDS', {
            fontSize: '24px',
            color: '#888888',
            fontFamily: 'Electrolize',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // Calculation value display (top middle, above hand - positioned to avoid overlap with selected cards)
        // Match the same style as battle stat indicators on the field
        // Position so text (70px below icon) clears the top of scaled cards (height - 396)
        this.calculationValueContainer = this.add.container(width / 2, height - 517);
        this.calculationValueIcon = this.add.image(0, 0, 'ui_attack').setScale(0.8).setVisible(false);
        this.calculationValueText = this.add.text(0, 70, '', {
            fontSize: '48px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5);
        this.calculationValueContainer.add([this.calculationValueIcon, this.calculationValueText]);
        
        this.actionButton.on('pointerdown', () => {
            if (this.isDiscardMode) {
                this.handleDiscardButton();
            } else {
                this.handleActionButton();
            }
        });
        
        // Discard mode toggle button (bottom left, same height as action button)
        this.discardModeButton = this.add.rectangle(150, height - 80, 250, 80, 0x444444);
        this.discardModeButton.setStrokeStyle(4, 0xffffff);
        this.discardModeButton.setAlpha(0);
        
        this.discardModeText = this.add.text(150, height - 80, 'DISCARD', {
            fontSize: '24px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        this.discardModeText.setAlpha(0);
        
        this.discardModeButton.on('pointerdown', () => {
            this.toggleDiscardMode();
        });

        // Battle stats indicators (icons + values)
        this.playerBattleStat = this.add.container(width * 0.4, 400).setAlpha(0);
        this.playerBattleStatIcon = this.add.image(0, 0, 'ui_attack').setScale(0.8);
        this.playerBattleStatText = this.add.text(0, 70, '0', {
            fontSize: '48px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5);
        this.playerBattleStat.add([this.playerBattleStatIcon, this.playerBattleStatText]);

        this.enemyBattleStat = this.add.container(width * 0.6, 400).setAlpha(0);
        this.enemyBattleStatIcon = this.add.image(0, 0, 'ui_defense').setScale(0.8);
        this.enemyBattleStatText = this.add.text(0, 70, '0', {
            fontSize: '48px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5);
        this.enemyBattleStat.add([this.enemyBattleStatIcon, this.enemyBattleStatText]);

        // Guide Button (?) in top right, below enemy HP circle
        const guideBtnX = width - 45;
        const guideBtnY = 125 + (height * 0.03);
        
        this.guideButton = this.add.circle(guideBtnX, guideBtnY, 25, 0x444444)
            .setStrokeStyle(3, 0xffffff)
            .setInteractive({ useHandCursor: true });
            
        this.guideButton.on('pointerover', () => this.guideButton.setFillStyle(0x666666));
        this.guideButton.on('pointerout', () => this.guideButton.setFillStyle(0x444444));
            
        this.guideButtonText = this.add.text(guideBtnX, guideBtnY, '?', {
            fontSize: '32px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // Guide Panel (Dropdown)
        const panelOpenY = guideBtnY + 35;
        const panelClosedY = panelOpenY - 10;
        
        this.guidePanel = this.add.container(width - 20, panelOpenY).setAlpha(0).setDepth(100);
        
        const guideImg = this.add.image(0, 0, 'ui_guide').setOrigin(1, 0).setScale(0.8);
        
        this.guidePanel.add(guideImg);
        
        // Toggle logic
        this.guideButton.on('pointerdown', () => {
            soundManager.playClick();
            const isVisible = this.guidePanel.alpha > 0;
            
            if (isVisible) {
                this.tweens.add({
                    targets: this.guidePanel,
                    alpha: 0,
                    y: panelClosedY,
                    duration: 200,
                    ease: 'Power2'
                });
            } else {
                this.guidePanel.y = panelClosedY;
                this.tweens.add({
                    targets: this.guidePanel,
                    alpha: 1,
                    y: panelOpenY,
                    duration: 300,
                    ease: 'Back.easeOut'
                });
            }
        });
        
        // Close guide when clicking anywhere else
        this.input.on('pointerdown', (pointer, currentlyOver) => {
            if (this.guidePanel.alpha > 0 && !currentlyOver.includes(this.guideButton) && !currentlyOver.includes(guideImg)) {
                this.tweens.add({
                    targets: this.guidePanel,
                    alpha: 0,
                    y: panelClosedY,
                    duration: 200,
                    ease: 'Power2'
                });
            }
        });
    }
    
    displayHands() {
        const { width, height } = this.cameras.main;
        const hand = gameState.playerHand;
        const cardSpacing = 220;
        const startX = width / 2 - ((hand.length - 1) * cardSpacing) / 2;
        const handY = height - 220;
        
        // Track which cards are already in visual hand to avoid duplicating animations
        const existingCardData = this.handCards ? this.handCards.map(c => c.cardData) : [];
        
        // Destroy cards that are no longer in hand
        if (this.handCards) {
            this.handCards.forEach(card => {
                if (!hand.includes(card.cardData)) {
                    // This card was discarded or played - let it fall off screen
                    card.disableInteractive();
                    this.tweens.add({
                        targets: card,
                        y: height + 400,
                        alpha: 0,
                        rotation: Math.random() * 0.5 - 0.25,
                        duration: 600,
                        ease: 'Back.easeIn',
                        onComplete: () => card.destroy()
                    });
                }
            });
            // Only keep cards that are still in hand
            this.handCards = this.handCards.filter(card => hand.includes(card.cardData));
        } else {
            this.handCards = [];
        }
        
        // Update positions of existing cards and add new ones
        hand.forEach((cardData, index) => {
            const targetX = startX + index * cardSpacing;
            let card = this.handCards.find(c => c.cardData === cardData);
            
            if (card) {
                // Animate existing card to its new position in the hand
                this.tweens.add({
                    targets: card,
                    x: targetX,
                    y: handY,
                    duration: 400,
                    ease: 'Cubic.easeOut'
                });
            } else {
                // This is a new card - animate it coming up from the bottom
                card = new Card(this, targetX, height + 400, cardData);
                card.cardData = cardData;
                this.handCards.push(card);
                
                this.tweens.add({
                    targets: card,
                    y: handY,
                    duration: 600,
                    delay: index * 50,
                    ease: 'Back.easeOut'
                });
            }

            // ALWAYS refresh interactivity for all cards in hand
            card.removeAllListeners('pointerdown');
            if (this.canInteractWithCards) {
                card.on('pointerdown', () => this.handleCardClick(card));
            }
        });
    }
    
    handleCardClick(card) {
        // Don't handle clicks if player can't interact with cards
        if (!this.canInteractWithCards) {
            return;
        }
        
        const cardData = card.cardData;
        
        // Discard mode - select any cards to discard
        if (this.isDiscardMode && this.currentPhase === 'ATTACKING') {
            soundManager.playCardSelect();
            const index = this.selectedDiscards.indexOf(card);
            if (index > -1) {
                // Deselecting - remove from discards and stop jiggle
                this.selectedDiscards.splice(index, 1);
                card.highlight(false);
                if (card.jiggleTween) {
                    card.jiggleTween.stop();
                    card.setRotation(0);
                    card.jiggleTween = null;
                }
            } else {
                // Selecting - add to discards and start jiggle animation
                this.selectedDiscards.push(card);
                card.highlight(true);
                
                // Create jiggle animation (subtle wiggle)
                card.jiggleTween = this.tweens.add({
                    targets: card,
                    rotation: { from: -0.0375, to: 0.0375 },
                    duration: 100,
                    yoyo: true,
                    repeat: -1,
                    ease: 'Sine.easeInOut'
                });
            }
            this.updateActionButton();
            return;
        }
        
        // Healing card selection (only during attacking phase)
        if (cardData.type === 'healing') {
            if (this.currentPhase === 'ATTACKING') {
                soundManager.playCardSelect();
                // Clear all other selections when selecting a healing card
                this.handCards.forEach(c => {
                    c.highlight(false);
                    c.setDepth(0);
                });
                this.selectedCreature = null;
                this.selectedElement = null;
                this.selectedModifiers = [];
                
                if (this.selectedHealing === card) {
                    this.selectedHealing = null;
                } else {
                    this.selectedHealing = card;
                    card.highlight(true);
                    card.setDepth(1000); // Bring to front
                }
            } else {
                soundManager.playError();
            }
            this.updateActionButton();
            return;
        }
        
        // Normal mode - select cards for playing
        if (cardData.type === 'creature') {
            soundManager.playCardSelect();
            // Clear healing selection when selecting a creature
            if (this.selectedHealing) {
                this.handCards.forEach(c => {
                    if (c.cardData.type === 'healing') c.highlight(false);
                });
                this.selectedHealing = null;
            }
            
            // Deselect all creatures
            this.handCards.forEach(c => {
                if (c.cardData.type === 'creature') {
                    c.highlight(false);
                    c.setDepth(0);
                }
            });
            
            if (this.selectedCreature === card) {
                this.selectedCreature = null;
                card.setDepth(0); // Reset depth
            } else {
                this.selectedCreature = card;
                card.highlight(true);
                card.setDepth(1000); // Bring to front
            }
        } else if (cardData.type === 'element') {
            // Check if element is valid for defense if in defense phase
            let isInvalidElement = false;
            if (this.currentPhase === 'DEFENDING') {
                const attackElement = this.attackingCards?.element?.id;
                const requiredElementId = attackElement ? ELEMENT_COUNTERS[attackElement] : null;
                if (requiredElementId && cardData.id !== requiredElementId) {
                    isInvalidElement = true;
                }
            }

            if (isInvalidElement) {
                soundManager.playError();
            } else {
                soundManager.playCardSelect();
                // Clear healing selection when selecting an element
                if (this.selectedHealing) {
                    this.handCards.forEach(c => {
                        if (c.cardData.type === 'healing') c.highlight(false);
                    });
                    this.selectedHealing = null;
                }
                
                // Deselect all elements
                this.handCards.forEach(c => {
                    if (c.cardData.type === 'element') {
                        c.highlight(false);
                        c.setDepth(0);
                    }
                });
                
                if (this.selectedElement === card) {
                    this.selectedElement = null;
                    card.setDepth(0); // Reset depth
                } else {
                    this.selectedElement = card;
                    card.highlight(true);
                    card.setDepth(1000); // Bring to front
                }
            }
        } else if (cardData.type === 'attack_modifier') {
            if (this.currentPhase === 'ATTACKING') {
                soundManager.playCardSelect();
                // Clear healing selection when selecting a modifier
                if (this.selectedHealing) {
                    this.handCards.forEach(c => {
                        if (c.cardData.type === 'healing') c.highlight(false);
                    });
                    this.selectedHealing = null;
                }
                
                // Toggle attack modifier
                const index = this.selectedModifiers.indexOf(card);
                if (index > -1) {
                    this.selectedModifiers.splice(index, 1);
                    card.highlight(false);
                    card.setDepth(0); // Reset depth
                } else {
                    this.selectedModifiers.push(card);
                    card.highlight(true);
                    card.setDepth(1000); // Bring to front
                }
            } else {
                soundManager.playError();
            }
        } else if (cardData.type === 'defense_modifier') {
            if (this.currentPhase === 'DEFENDING') {
                soundManager.playCardSelect();
                // Toggle defense modifier
                const index = this.selectedModifiers.indexOf(card);
                if (index > -1) {
                    this.selectedModifiers.splice(index, 1);
                    card.highlight(false);
                    card.setDepth(0); // Reset depth
                } else {
                    this.selectedModifiers.push(card);
                    card.highlight(true);
                    card.setDepth(1000); // Bring to front
                }
            } else {
                soundManager.playError();
            }
        }
        
        this.updateActionButton();
    }
    
    updateActionButton() {
        // Don't update buttons if player can't interact with cards
        if (!this.canInteractWithCards) {
            if (this.calculationValueContainer) this.calculationValueContainer.setAlpha(0);
            return;
        }
        
        const hasCreature = this.selectedCreature !== null;
        const hasHealing = this.selectedHealing !== null;
        
        // Update calculation value display
        if (this.calculationValueContainer) {
            if (this.isDiscardMode) {
                this.calculationValueContainer.setAlpha(0);
            } else {
                this.calculationValueContainer.setAlpha(1);
                let total = 0;
                let iconTexture = "";
                let showIcon = false;
                
                if (hasCreature) {
                    if (this.currentPhase === 'ATTACKING') {
                        total = this.selectedCreature.cardData.baseStats.attack;
                        this.selectedModifiers.forEach(mod => {
                            if (mod.cardData.type === 'attack_modifier') {
                                total += mod.cardData.modifier;
                            }
                        });
                        iconTexture = "ui_attack";
                        showIcon = true;
                    } else if (this.currentPhase === 'DEFENDING') {
                        total = this.selectedCreature.cardData.baseStats.defense;
                        this.selectedModifiers.forEach(mod => {
                            if (mod.cardData.type === 'defense_modifier') {
                                total += mod.cardData.modifier;
                            }
                        });
                        iconTexture = "ui_defense";
                        showIcon = true;
                    }
                } else if (hasHealing && this.currentPhase === 'ATTACKING') {
                    total = this.selectedHealing.cardData.healing;
                    showIcon = false; // No icon for healing, just show "+X" in green
                }
                
                if (showIcon || (hasHealing && this.currentPhase === 'ATTACKING')) {
                    if (showIcon) {
                        this.calculationValueIcon.setTexture(iconTexture);
                        this.calculationValueIcon.setVisible(true);
                        this.calculationValueText.setText(`${total}`);
                        this.calculationValueText.setColor('#ffffff');
                    } else if (hasHealing) {
                        this.calculationValueIcon.setVisible(false);
                        this.calculationValueText.setText(`+${total}`);
                        this.calculationValueText.setColor('#00ff00');
                    }
                } else {
                    this.calculationValueIcon.setVisible(false);
                    this.calculationValueText.setText('');
                }
            }
        }
        
        if (this.currentPhase === 'ATTACKING') {
            // Show discard mode toggle button
            this.discardModeButton.setAlpha(1);
            this.discardModeButton.setInteractive({ useHandCursor: true });
            this.discardModeText.setAlpha(1);
            
            if (this.isDiscardMode) {
                // In discard mode - button becomes discard & pass
                if (this.selectedDiscards.length > 0) {
                    this.actionButton.setFillStyle(0xaa6600);
                    this.actionButton.setInteractive({ useHandCursor: true });
                    this.actionButtonText.setText(`DISCARD ${this.selectedDiscards.length} & PASS`);
                    this.actionButtonText.setColor('#ffffff');
                } else {
                    this.actionButton.setFillStyle(0x666666);
                    this.actionButton.disableInteractive();
                    this.actionButtonText.setText('SELECT CARDS');
                    this.actionButtonText.setColor('#888888');
                }
            } else if (hasHealing) {
                // Healing card selected - button is heal
                this.actionButton.setFillStyle(0x00aa00);
                this.actionButton.setInteractive({ useHandCursor: true });
                this.actionButtonText.setText('HEAL!');
                this.actionButtonText.setColor('#ffffff');
            } else {
                // In attack mode - button is attack
                if (hasCreature) {
                    this.actionButton.setFillStyle(0xff0000);
                    this.actionButton.setInteractive({ useHandCursor: true });
                    this.actionButtonText.setText('ATTACK!');
                    this.actionButtonText.setColor('#ffffff');
                } else {
                    this.actionButton.setFillStyle(0x666666);
                    this.actionButton.disableInteractive();
                    this.actionButtonText.setText('SELECT CREATURE');
                    this.actionButtonText.setColor('#888888');
                }
            }
        } else if (this.currentPhase === 'DEFENDING') {
            // Hide discard mode button during defending
            this.discardModeButton.setAlpha(0);
            this.discardModeButton.disableInteractive();
            this.discardModeText.setAlpha(0);
            
            const attackElement = this.attackingCards?.element?.id;
            const requiredElementId = attackElement ? ELEMENT_COUNTERS[attackElement] : null;
            const hasCorrectElement = !requiredElementId || (this.selectedElement && this.selectedElement.cardData.id === requiredElementId);
            
            if (hasCreature && hasCorrectElement) {
                this.actionButton.setFillStyle(0x0000ff);
                this.actionButton.setInteractive({ useHandCursor: true });
                this.actionButtonText.setText('DEFEND!');
                this.actionButtonText.setColor('#ffffff');
            } else if (hasCreature && !hasCorrectElement) {
                this.actionButton.setFillStyle(0x666666);
                this.actionButton.setInteractive({ useHandCursor: true }); 
                // Let's make it clear what's needed.
                this.actionButtonText.setText(`NEED ${requiredElementId.toUpperCase()}`);
                this.actionButtonText.setColor('#ffaaaa');
            } else {
                this.actionButton.setFillStyle(0x666666);
                this.actionButton.setInteractive({ useHandCursor: true });
                this.actionButtonText.setText('PASS');
                this.actionButtonText.setColor('#ffffff');
            }
        }
    }
    
    toggleDiscardMode() {
        soundManager.playClick();
        this.isDiscardMode = !this.isDiscardMode;
        
        // Clear all selections and stop any jiggle animations
        this.handCards.forEach(c => {
            c.highlight(false);
            // Stop jiggle animation if it exists
            if (c.jiggleTween) {
                c.jiggleTween.stop();
                c.setRotation(0);
            }
        });
        this.selectedCreature = null;
        this.selectedElement = null;
        this.selectedModifiers = [];
        this.selectedDiscards = [];
        this.selectedHealing = null;
        
        if (this.isDiscardMode) {
            // Entering discard mode - change to gold and text to "Cancel"
            this.discardModeButton.setFillStyle(0xFFD700);
            this.discardModeText.setText('CANCEL');
            this.instructionText.setText('Select any cards to discard and draw new ones');
        } else {
            // Exiting discard mode - back to dark gray and text to "Discard"
            this.discardModeButton.setFillStyle(0x444444);
            this.discardModeText.setText('DISCARD');
            this.instructionText.setText('Select 1 Creature + Optional Element + Any Attack Modifiers');
        }
        
        // Update the action button to reflect the new mode
        this.updateActionButton();
    }
    
    handleDiscardButton() {
        if (this.selectedDiscards.length === 0) return;
        
        // Hide calculation value display immediately when discard button is clicked
        if (this.calculationValueContainer) {
            this.calculationValueContainer.setAlpha(0);
        }
        
        soundManager.playCardSelect();
        
        const numDiscarded = this.selectedDiscards.length;
        
        // Stop jiggle animations and discard selected cards
        this.selectedDiscards.forEach(card => {
            if (card.jiggleTween) {
                card.jiggleTween.stop();
                card.setRotation(0);
            }
            gameState.discardCard(card.cardData, true);
        });
        
        // Draw same number of cards
        for (let i = 0; i < numDiscarded; i++) {
            gameState.drawCard(true);
        }
        
        this.selectedDiscards = [];
        
        // Update hand display immediately
        this.displayHands();
        
        // Show message
        this.instructionText.setText(`Discarded ${numDiscarded} card${numDiscarded > 1 ? 's' : ''} and drew ${numDiscarded} new card${numDiscarded > 1 ? 's' : ''}. Passing turn...`);
        
        // Exit discard mode and disable all interaction
        this.isDiscardMode = false;
        this.canInteractWithCards = false; // Disable card interaction
        
        // Reset discard button color to default
        this.discardModeButton.setFillStyle(0x444444);
        
        // Hide all buttons
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        // Change hue to red - player cannot act
        this.setTurnHue(false);
        
        this.time.delayedCall(1500, () => {
            this.enemyTurn();
        });
    }
    
    createFusionExplosion(x, y) {
        // Create multiple particle rings expanding outward
        const colors = [0xffff00, 0xff9900, 0xff00ff, 0x00ffff, 0xff0000];
        const particleCount = 30;
        
        for (let i = 0; i < particleCount; i++) {
            const angle = (i / particleCount) * Math.PI * 2;
            const color = colors[i % colors.length];
            
            // Create particle
            const particle = this.add.circle(x, y, 6, color);
            particle.setAlpha(1);
            
            // Calculate end position
            const distance = Phaser.Math.Between(100, 250);
            const endX = x + Math.cos(angle) * distance;
            const endY = y + Math.sin(angle) * distance;
            
            // Animate particle explosion
            this.tweens.add({
                targets: particle,
                x: endX,
                y: endY,
                alpha: 0,
                scale: 0,
                duration: 800,
                ease: 'Cubic.easeOut',
                onComplete: () => particle.destroy()
            });
        }
        
        // Add flash effect
        const flash = this.add.circle(x, y, 200, 0xffffff, 0.8);
        this.tweens.add({
            targets: flash,
            alpha: 0,
            scale: 2,
            duration: 400,
            ease: 'Cubic.easeOut',
            onComplete: () => flash.destroy()
        });
        
        // Add expanding rings
        for (let i = 0; i < 3; i++) {
            this.time.delayedCall(i * 100, () => {
                const ring = this.add.circle(x, y, 10, 0xffff00, 0);
                ring.setStrokeStyle(4, 0xffff00, 1);
                
                this.tweens.add({
                    targets: ring,
                    scale: 5,
                    alpha: 0,
                    duration: 600,
                    ease: 'Cubic.easeOut',
                    onComplete: () => ring.destroy()
                });
            });
        }
        
        // Add star burst particles
        for (let i = 0; i < 12; i++) {
            const angle = (i / 12) * Math.PI * 2;
            const star = this.add.star(x, y, 5, 4, 8, 0xffff00);
            
            const endX = x + Math.cos(angle) * 150;
            const endY = y + Math.sin(angle) * 150;
            
            this.tweens.add({
                targets: star,
                x: endX,
                y: endY,
                alpha: 0,
                rotation: Math.PI * 4,
                duration: 1000,
                ease: 'Cubic.easeOut',
                onComplete: () => star.destroy()
            });
        }
    }
    
    handleActionButton() {
        // Hide calculation value display immediately when action button is clicked
        if (this.calculationValueContainer) {
            this.calculationValueContainer.setAlpha(0);
        }
        
        if (this.currentPhase === 'ATTACKING' && !this.isDiscardMode) {
            if (this.selectedHealing) {
                this.playHealingCard();
            } else {
                this.completeAttackPhase();
            }
        } else if (this.currentPhase === 'DEFENDING') {
            const attackElement = this.attackingCards?.element?.id;
            const requiredElementId = attackElement ? ELEMENT_COUNTERS[attackElement] : null;
            const hasCorrectElement = !requiredElementId || (this.selectedElement && this.selectedElement.cardData.id === requiredElementId);
            
            if (this.selectedCreature && !hasCorrectElement) {
                soundManager.playError();
                return;
            }
            this.completeDefendPhase();
        }
    }
    
    playHealingCard() {
        if (!this.selectedHealing) return;
        
        // Disable interaction immediately to prevent spamming
        this.canInteractWithCards = false;
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        soundManager.playHeal();
        
        const healingCard = this.selectedHealing.cardData;
        const healAmount = healingCard.healing;
        
        // Calculate actual healing (can't exceed max HP)
        const maxHP = CONFIG.playerHP;
        const actualHeal = Math.min(healAmount, maxHP - gameState.playerHP);
        gameState.playerHP += actualHeal;
        
        // Update HP display
        this.updatePlayerHP();
        
        // Hide the healing card from hand immediately
        this.selectedHealing.setAlpha(0);
        this.selectedHealing.disableInteractive();
        
        // Display healing card on player's side (left) with animation from hand
        const { width, height } = this.cameras.main;
        this.playerPlayedCards.forEach(card => card.destroy());
        this.playerPlayedCards = [];
        
        const startX = width / 2;
        const startY = height - 220;
        const targetX = width / 4;
        const targetY = 400;
        
        const displayedCard = new Card(this, startX, startY, healingCard);
        displayedCard.setScale(1.0);
        displayedCard.setAlpha(0.8);
        this.playerPlayedCards.push(displayedCard);
        
        // Animate card to field position
        this.tweens.add({
            targets: displayedCard,
            x: targetX,
            y: targetY,
            alpha: 1,
            duration: 400,
            ease: 'Cubic.easeOut'
        });
        
        // Discard healing card and draw 1 new card
        gameState.discardCard(healingCard, true);
        gameState.drawCard(true);
        
        // Clear selection
        this.selectedHealing = null;
        
        // Update hand display and pass to enemy
        this.time.delayedCall(2000, () => {
            // Clear played cards with slide animation
            this.playerPlayedCards.forEach(card => {
                this.tweens.add({
                    targets: card,
                    x: -200,
                    duration: 400,
                    ease: 'Back.easeIn',
                    onComplete: () => {
                        card.destroy();
                    }
                });
            });
            this.playerPlayedCards = [];
            
            // Clear logical card tracking
            this.attackingCards = null;
            this.defendingCards = null;
            
            this.updateBattleStatsUI();
            
            this.displayHands();
            this.time.delayedCall(500, () => {
                this.enemyTurn();
            });
        });
    }
    
    async completeAttackPhase() {
        if (!this.selectedCreature) return;
        
        // Disable interaction immediately to prevent spamming
        this.canInteractWithCards = false;
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        soundManager.playAttack();
        
        // Count cards played
        let cardsPlayed = 1; // creature
        if (this.selectedElement) cardsPlayed++;
        cardsPlayed += this.selectedModifiers.length;
        
        // Store attacking cards
        this.attackingCards = {
            creature: this.selectedCreature.cardData,
            element: this.selectedElement ? this.selectedElement.cardData : null,
            modifiers: this.selectedModifiers.map(c => c.cardData),
            isEnemy: false
        };
        
        // Debug: Log the creature data
        console.log('Attack - Creature data:', this.attackingCards.creature);
        console.log('Attack - Creature imageUrl:', this.attackingCards.creature.imageUrl);
        console.log('Attack - Element:', this.attackingCards.element);
        console.log('Attack - Modifiers:', this.attackingCards.modifiers);
        
        // Check if we should generate a fusion image
        const shouldGenerate = FusionGenerator.shouldGenerateFusion(
            this.attackingCards.creature,
            this.attackingCards.element,
            this.attackingCards.modifiers
        );
        
        console.log('Should generate fusion?', shouldGenerate);
        
        // Only show fusion effect if there's an element (actual fusion)
        const hasFusion = !!this.attackingCards.element;
        console.log('Has fusion (element present)?', hasFusion);
        
        // Display player's played cards AFTER potential fusion generation
        if (shouldGenerate && hasFusion) {
            console.log('Should generate fusion - creature:', this.attackingCards.creature.name);
            
            try {
                const fusionImageUrl = await FusionGenerator.generateFusionImage(
                    this.attackingCards.creature,
                    this.attackingCards.element,
                    this.attackingCards.modifiers
                );
                
                console.log('Received fusion URL:', fusionImageUrl);
                
                if (fusionImageUrl) {
                    // Store the fusion image URL for display
                    this.attackingCards.fusionImageUrl = fusionImageUrl;
                    console.log('Stored fusion URL in attackingCards');
                    soundManager.playFusion();
                    
                    // Trigger explosion effect at card position (player's side - left)
                    this.createFusionExplosion(this.cameras.main.width / 4, 400);
                } else {
                    console.warn('No fusion URL returned - falling back to regular display');
                }
            } catch (error) {
                console.error('Failed to generate fusion image:', error);
            }
        } else {
            console.log('Should NOT generate fusion - creature has imageUrl:', !!this.attackingCards.creature.imageUrl);
        }
        
        // Hide the cards from hand immediately before playing them to field
        const cardsToHide = [this.selectedCreature];
        if (this.selectedElement) cardsToHide.push(this.selectedElement);
        cardsToHide.push(...this.selectedModifiers);
        
        cardsToHide.forEach(card => {
            card.setAlpha(0);
            card.disableInteractive();
        });
        
        // NOW display player's played cards in the center (below enemy cards position)
        this.playerPlayedCards.forEach(card => card.destroy());
        this.playerPlayedCards = this.displayPlayedCards(this.attackingCards, 400, true);
        this.updateBattleStatsUI();
        console.log('Displayed player cards, count:', this.playerPlayedCards.length);
        
        // Remove cards from hand
        gameState.discardCard(this.attackingCards.creature, true);
        if (this.attackingCards.element) {
            gameState.discardCard(this.attackingCards.element, true);
        }
        this.attackingCards.modifiers.forEach(mod => {
            gameState.discardCard(mod, true);
        });
        
        // Draw same number of cards
        for (let i = 0; i < cardsPlayed; i++) {
            gameState.drawCard(true);
        }
        
        // Clear selections
        this.selectedCreature = null;
        this.selectedElement = null;
        this.selectedModifiers = [];
        
        // Player cannot act while enemy is defending
        this.setTurnHue(false);
        this.canInteractWithCards = false;
        
        // Move to defending phase - still PLAYER'S turn, just defending phase
        this.currentPhase = 'DEFENDING';
        this.updateTurnDisplay('YOU', 'DEFENDING', 0xffaa00);
        this.instructionText.setText('Enemy is choosing their defense...');
        
        // Enemy AI chooses defense
        this.time.delayedCall(1500, () => {
            this.enemyDefend();
        });
    }
    
    displayPlayedCards(playedCards, yPosition, isPlayer = true) {
        console.log('displayPlayedCards called with fusionImageUrl:', playedCards.fusionImageUrl);
        
        const cards = [];
        const { width, height } = this.cameras.main;
        
        // Calculate center x position for the main creature/fusion
        const centerX = isPlayer ? width / 4 : (width * 3) / 4;
        
        // Starting position (from hand area)
        const startY = isPlayer ? height - 220 : 220; // Player from bottom, enemy from top
        const startX = isPlayer ? width / 2 : width / 2; // Start from center
        
        // Configuration for vertical list layout
        const modScale = 0.65;
        const modXOffset = 200; // Distance to the side of the main card
        const modSpacingY = 110; // Vertical distance between modifiers in the list
        // Grow away from center line: Player modifiers to the left, Enemy to the right
        const growDirection = isPlayer ? -1 : 1; 
        
        // 1. Determine main card properties
        const isFusion = !!playedCards.fusionImageUrl;
        const elementColor = playedCards.element ? playedCards.element.color : null;
        const modifierCount = (playedCards.modifiers && playedCards.modifiers.length) || 0;

        // 2. Display Main Creature/Fusion (centered) - start from hand position
        let mainCard;
        if (isFusion) {
            mainCard = new Card(
                this, 
                startX, 
                startY, 
                playedCards.creature,
                playedCards.fusionImageUrl,
                elementColor
            );
        } else {
            mainCard = new Card(this, startX, startY, playedCards.creature);
        }
        mainCard.setScale(1.0);
        mainCard.setAlpha(0.8);
        cards.push(mainCard);
        
        // Animate main card to field position
        this.tweens.add({
            targets: mainCard,
            x: centerX,
            y: yPosition,
            alpha: 1,
            duration: 400,
            ease: 'Cubic.easeOut'
        });

        // 3. Display Modifiers in a vertical list to the side with horizontal skew
        if (modifierCount > 0) {
            const modBaseX = centerX + (modXOffset * growDirection);
            // Center the column of modifiers vertically relative to the main card's Y
            const targetStartY = yPosition - ((modifierCount - 1) * modSpacingY) / 2;
            // Horizontal offset per card (negative to skew outward from center)
            const xSkewPerCard = 30 * growDirection; // Skew away from center
            
            playedCards.modifiers.forEach((mod, index) => {
                const targetModX = modBaseX + (index * xSkewPerCard);
                const targetModY = targetStartY + (index * modSpacingY);
                
                // Start from hand position
                const modCard = new Card(this, startX, startY, mod);
                modCard.setScale(0);
                modCard.setAlpha(0.8);
                cards.push(modCard);
                
                // Animate to field position with stagger
                this.tweens.add({
                    targets: modCard,
                    x: targetModX,
                    y: targetModY,
                    scaleX: modScale,
                    scaleY: modScale,
                    alpha: 1,
                    duration: 400,
                    delay: 100 + (index * 80),
                    ease: 'Cubic.easeOut'
                });
            });
        }

        // 4. Display Element card (small icon style)
        if (playedCards.element) {
            const targetElemX = centerX - (120 * growDirection);
            const targetElemY = yPosition - 130;
            
            // Start from hand position
            const elementCard = new Card(this, startX, startY, playedCards.element);
            elementCard.setScale(0);
            elementCard.setAlpha(0.8);
            cards.push(elementCard);
            
            // Animate to field position
            this.tweens.add({
                targets: elementCard,
                x: targetElemX,
                y: targetElemY,
                scaleX: 0.5,
                scaleY: 0.5,
                alpha: 1,
                duration: 400,
                delay: 50,
                ease: 'Cubic.easeOut'
            });
        }
        
        return cards;
    }
    
    async enemyDefend() {
        // Clear previous enemy played cards
        this.enemyPlayedCards.forEach(card => card.destroy());
        this.enemyPlayedCards = [];
        
        const attackElement = this.attackingCards?.element?.id;
        const requiredElementId = attackElement ? ELEMENT_COUNTERS[attackElement] : null;
        
        // Simple AI: try to block with a creature
        const enemyCreature = gameState.enemyHand.find(c => c.type === 'creature');
        
        // Find the required element if necessary
        let enemyElement = null;
        if (requiredElementId) {
            enemyElement = gameState.enemyHand.find(c => c.type === 'element' && c.id === requiredElementId);
        } else {
            enemyElement = gameState.enemyHand.find(c => c.type === 'element');
        }
        
        const canEnemyDefend = enemyCreature && (!requiredElementId || enemyElement);
        const enemyDefMod = gameState.enemyHand.find(c => c.type === 'defense_modifier');
        
        let cardsPlayed = 0;
        
        if (canEnemyDefend) {
            this.defendingCards = {
                creature: enemyCreature,
                element: enemyElement || null,
                modifiers: enemyDefMod ? [enemyDefMod] : [],
                isEnemy: true
            };
            
            // Check if we should generate a fusion image for enemy defense
            const shouldGenerate = FusionGenerator.shouldGenerateFusion(
                enemyCreature,
                enemyElement,
                enemyDefMod ? [enemyDefMod] : []
            );
            
            // Only show fusion effect if there's an element (actual fusion)
            const hasFusion = !!enemyElement;
            
            if (shouldGenerate && hasFusion) {
                try {
                    const fusionImageUrl = await FusionGenerator.generateFusionImage(
                        enemyCreature,
                        enemyElement,
                        enemyDefMod ? [enemyDefMod] : []
                    );
                    
                    if (fusionImageUrl) {
                        this.defendingCards.fusionImageUrl = fusionImageUrl;
                    }
                } catch (error) {
                    console.error('Error generating enemy defense fusion:', error);
                }
            }
            
            // Show enemy's played cards (with fusion if available)
            this.enemyPlayedCards = this.displayPlayedCards(this.defendingCards, 400, false);
            this.updateBattleStatsUI();
            
            // Play fusion animation after cards are displayed
            if (shouldGenerate && hasFusion && this.defendingCards.fusionImageUrl) {
                soundManager.playFusion();
                this.createFusionExplosion(this.cameras.main.width * 3 / 4, 400);
            }
            
            cardsPlayed = 1; // creature
            if (enemyElement) cardsPlayed++;
            if (enemyDefMod) cardsPlayed++;
            
            gameState.discardCard(enemyCreature, false);
            if (enemyElement) {
                gameState.discardCard(enemyElement, false);
            }
            if (enemyDefMod) {
                gameState.discardCard(enemyDefMod, false);
            }
            
            // Enemy draws cards equal to what they played
            for (let i = 0; i < cardsPlayed; i++) {
                gameState.drawCard(false);
            }
            
            this.instructionText.setText('Enemy blocks with their cards!');
        } else {
            this.defendingCards = null;
            this.instructionText.setText('Enemy has no creatures to block!');
        }
        

        
        this.time.delayedCall(1500, () => {
            this.resolveCombat();
        });
    }
    
    resolveCombat() {
        // Calculate attack
        let totalAttack = this.attackingCards.creature.baseStats.attack;
        this.attackingCards.modifiers.forEach(mod => {
            if (mod.type === 'attack_modifier') {
                totalAttack += mod.modifier;
            }
        });
        
        // Check elemental counter rules
        let canDefend = true;
        let defenseMessage = '';
        
        const attackElement = this.attackingCards.element?.id;
        const defendElement = this.defendingCards?.element?.id;
        
        if (attackElement && this.defendingCards && this.defendingCards.creature) {
            // Attacker has an element - check if defender can block
            if (!defendElement) {
                // Defender has no element - cannot block elemental attacks
                canDefend = false;
                defenseMessage = 'ELEMENTAL ATTACK!\nNo counter element!';
            } else {
                // Check element counter pairings
                if (ELEMENT_COUNTERS[attackElement] !== defendElement) {
                    // Wrong element counter
                    canDefend = false;
                    defenseMessage = `WRONG COUNTER!\n${attackElement.toUpperCase()} needs ${ELEMENT_COUNTERS[attackElement].toUpperCase()}!`;
                }
            }
        }
        
        // Calculate defense
        let totalDefense = 0;
        if (canDefend && this.defendingCards && this.defendingCards.creature) {
            totalDefense = this.defendingCards.creature.baseStats.defense;
            this.defendingCards.modifiers.forEach(mod => {
                if (mod.type === 'defense_modifier') {
                    totalDefense += mod.modifier;
                }
            });
        }
        
        // Calculate damage
        const damage = Math.max(0, totalAttack - totalDefense);
        gameState.enemyHP -= damage;
        
        if (damage > 0) {
            soundManager.playSlash();
        } else if (this.defendingCards) {
            soundManager.playBlock();
        }
        
        this.updateEnemyHP();
        
        // Show combat result in center of field
        let resultMessage = '';
        if (defenseMessage) {
            resultMessage += defenseMessage + '\n';
        }
        resultMessage += `${damage} DAMAGE!`;
        
        const resultText = this.add.text(this.cameras.main.width / 2, 400, 
            resultMessage,
            {
                fontSize: '43px',
                color: damage > 0 ? '#ff0000' : '#888888',
                fontFamily: 'Electrolize',
                fontStyle: 'bold',
                align: 'center',
                lineSpacing: 8
            }
        ).setOrigin(0.5, 0.5);
        
        this.tweens.add({
            targets: resultText,
            alpha: 0,
            y: 350,
            duration: 2000,
            ease: 'Expo.easeIn',
            onComplete: () => resultText.destroy()
        });
        
        // Check for victory/defeat
        if (gameState.enemyHP <= 0) {
            this.time.delayedCall(2000, () => {
                this.handleVictory();
            });
            return;
        }
        
        // Clear both player and enemy played cards with animation, update hand display, then move to enemy turn
        this.time.delayedCall(2000, () => {
            this.clearPlayedCardsWithAnimation(() => {
                // Clear logical card tracking
                this.attackingCards = null;
                this.defendingCards = null;
                
                this.updateBattleStatsUI();
                
                // Update player's hand display before enemy turn
                this.displayHands();
                
                // Wait a moment for player to see their new hand
                this.time.delayedCall(500, () => {
                    // NOW the turn changes to enemy after player's defending phase completes
                    this.enemyTurn();
                });
            });
        });
    }
    
    async enemyTurn() {
        // Increment turn counter
        this.turnCount++;
        this.turnCounterText.setText(`TURN ${this.turnCount}`);
        
        // Player cannot act during enemy's turn
        this.setTurnHue(false);
        
        // Turn changes to ENEMY now - their attacking phase begins
        this.updateTurnDisplay('ENEMY', 'ATTACKING', 0xff4444);
        this.instructionText.setText('Enemy is attacking...');
        
        // Hide all buttons during enemy's turn
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        // Clear previous enemy played cards
        this.enemyPlayedCards.forEach(card => card.destroy());
        this.enemyPlayedCards = [];
        
        // Check if enemy should use healing (if HP is low and has healing card)
        const enemyHealing = gameState.enemyHand.find(c => c.type === 'healing');
        if (enemyHealing && gameState.enemyHP < CONFIG.enemyHP * 0.6) {
            // Enemy uses healing card
            soundManager.playHeal();
            const healAmount = enemyHealing.healing;
            const maxHP = CONFIG.enemyHP;
            const actualHeal = Math.min(healAmount, maxHP - gameState.enemyHP);
            gameState.enemyHP += actualHeal;
            
            // Update HP display
            this.updateEnemyHP();
            
            // Display enemy healing card on enemy's side (right) with animation from hand
            const { width, height } = this.cameras.main;
            const startX = width / 2;
            const startY = 220; // Enemy hand area at top
            const targetX = width * 3 / 4;
            const targetY = 400;
            
            const displayedCard = new Card(this, startX, startY, enemyHealing);
            displayedCard.setScale(1.0);
            displayedCard.setAlpha(0.8);
            this.enemyPlayedCards.push(displayedCard);
            
            // Animate card to field position
            this.tweens.add({
                targets: displayedCard,
                x: targetX,
                y: targetY,
                alpha: 1,
                duration: 400,
                ease: 'Cubic.easeOut'
            });
            
            this.instructionText.setText(`Enemy used ${enemyHealing.name} and healed ${actualHeal} HP!`);
            
            // Discard healing card and draw 1 new card
            gameState.discardCard(enemyHealing, false);
            gameState.drawCard(false);
            
    
            
            this.time.delayedCall(2000, () => {
                // Clear enemy played cards with slide animation
                this.enemyPlayedCards.forEach(card => {
                    this.tweens.add({
                        targets: card,
                        x: width + 200,
                        duration: 400,
                        ease: 'Back.easeIn',
                        onComplete: () => {
                            card.destroy();
                        }
                    });
                });
                this.enemyPlayedCards = [];
                
                this.startPlayerTurn();
            });
            return;
        }
        
        // Simple AI: attack with a creature if available
        const enemyCreature = gameState.enemyHand.find(c => c.type === 'creature');
        const enemyElement = gameState.enemyHand.find(c => c.type === 'element');
        const enemyAtkMod = gameState.enemyHand.find(c => c.type === 'attack_modifier');
        
        if (!enemyCreature) {
            // Enemy has no creatures - try to discard and draw new cards
            const totalAvailableCards = gameState.enemyDeck.length + gameState.enemyDiscard.length;
            
            if (gameState.enemyHand.length > 0 && totalAvailableCards > 0) {
                this.instructionText.setText('Enemy is discarding cards to draw new ones...');
                
                // Discard all cards in hand
                const cardsToDiscard = gameState.enemyHand.length;
                
                for (let i = 0; i < cardsToDiscard; i++) {
                    const card = gameState.enemyHand[0];
                    gameState.discardCard(card, false);
                }
                
                // Draw new cards (drawCard will automatically recycle discard pile if needed)
                for (let i = 0; i < cardsToDiscard; i++) {
                    gameState.drawCard(false);
                }
                
                // Update enemy hand display after discard/draw
                this.displayHands();
                
                this.time.delayedCall(1500, () => {
                    this.instructionText.setText('Enemy discarded and passed their turn!');
                    this.time.delayedCall(1000, () => {
                        this.startPlayerTurn();
                    });
                });
                return;
            } else {
                // Enemy passes - no creatures and no cards to cycle
                this.instructionText.setText('Enemy has no creatures and passes!');
                this.time.delayedCall(1500, () => {
                    this.startPlayerTurn();
                });
                return;
            }
        }
        
        let cardsPlayed = 0;
        
        this.attackingCards = {
            creature: enemyCreature,
            element: enemyElement || null,
            modifiers: enemyAtkMod ? [enemyAtkMod] : [],
            isEnemy: true
        };
        
        // Check if we should generate a fusion image for enemy attack
        const shouldGenerate = FusionGenerator.shouldGenerateFusion(
            enemyCreature,
            enemyElement,
            enemyAtkMod ? [enemyAtkMod] : []
        );
        
        // Only show fusion effect if there's an element (actual fusion)
        const hasFusion = !!enemyElement;
        
        if (shouldGenerate && hasFusion) {
            try {
                const fusionImageUrl = await FusionGenerator.generateFusionImage(
                    enemyCreature,
                    enemyElement,
                    enemyAtkMod ? [enemyAtkMod] : []
                );
                
                if (fusionImageUrl) {
                    this.attackingCards.fusionImageUrl = fusionImageUrl;
                }
            } catch (error) {
                console.error('Error generating enemy attack fusion:', error);
            }
        }
        
        // Show enemy's attacking cards (with fusion if available)
        this.enemyPlayedCards = this.displayPlayedCards(this.attackingCards, 400, false);
        this.updateBattleStatsUI();
        
        // Play fusion animation after cards are displayed
        if (shouldGenerate && hasFusion && this.attackingCards.fusionImageUrl) {
            soundManager.playFusion();
            this.createFusionExplosion(this.cameras.main.width * 3 / 4, 400);
        }
        
        cardsPlayed = 1; // creature
        if (enemyElement) cardsPlayed++;
        if (enemyAtkMod) cardsPlayed++;
        
        gameState.discardCard(enemyCreature, false);
        if (enemyElement) {
            gameState.discardCard(enemyElement, false);
        }
        if (enemyAtkMod) {
            gameState.discardCard(enemyAtkMod, false);
        }
        
        // Enemy draws cards equal to what they played
        for (let i = 0; i < cardsPlayed; i++) {
            gameState.drawCard(false);
        }
        

        
        this.time.delayedCall(1500, () => {
            this.playerDefend();
        });
    }
    
    playerDefend() {
        this.currentPhase = 'DEFENDING';
        this.isDiscardMode = false; // Ensure we're not in discard mode
        
        // Player can act now - they're defending
        this.setTurnHue(true);
        this.canInteractWithCards = true;
        
        // Still ENEMY's turn - player is defending against enemy's attack
        this.updateTurnDisplay('ENEMY', 'DEFENDING', 0x4444ff);
        this.instructionText.setText('Select 1 Creature + Optional Element + Any Defense Modifiers to block');
        
        // Reset button visibility for defending phase
        this.actionButton.setAlpha(1);
        this.actionButtonText.setAlpha(1);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        this.displayHands();
        this.updateActionButton();
    }
    
    async completeDefendPhase() {
        // Disable interaction immediately to prevent spamming
        this.canInteractWithCards = false;
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);

        soundManager.playAttack();
        
        let cardsPlayed = 0;
        
        if (this.selectedCreature) {
            // Player is blocking
            cardsPlayed = 1; // creature
            if (this.selectedElement) cardsPlayed++;
            cardsPlayed += this.selectedModifiers.length;
            
            this.defendingCards = {
                creature: this.selectedCreature.cardData,
                element: this.selectedElement ? this.selectedElement.cardData : null,
                modifiers: this.selectedModifiers.map(c => c.cardData),
                isEnemy: false
            };
            
            // Check if we should generate a fusion image for defense
            const shouldGenerate = FusionGenerator.shouldGenerateFusion(
                this.defendingCards.creature,
                this.defendingCards.element,
                this.defendingCards.modifiers
            );
            
            // Only show fusion effect if there's an element (actual fusion)
            const hasFusion = !!this.defendingCards.element;
            
            if (shouldGenerate && hasFusion) {
                try {
                    const fusionImageUrl = await FusionGenerator.generateFusionImage(
                        this.defendingCards.creature,
                        this.defendingCards.element,
                        this.defendingCards.modifiers
                    );
                    
                    if (fusionImageUrl) {
                        this.defendingCards.fusionImageUrl = fusionImageUrl;
                        soundManager.playFusion();
                        
                        // Trigger explosion effect at card position (player's side - left)
                        this.createFusionExplosion(this.cameras.main.width / 4, 400);
                    }
                } catch (error) {
                    console.error('Failed to generate defense fusion image:', error);
                }
            }
            
            // Hide the cards from hand immediately before playing them to field
            const cardsToHide = [this.selectedCreature];
            if (this.selectedElement) cardsToHide.push(this.selectedElement);
            cardsToHide.push(...this.selectedModifiers);
            
            cardsToHide.forEach(card => {
                card.setAlpha(0);
                card.disableInteractive();
            });
            
            gameState.discardCard(this.defendingCards.creature, true);
            if (this.defendingCards.element) {
                gameState.discardCard(this.defendingCards.element, true);
            }
            this.defendingCards.modifiers.forEach(mod => {
                gameState.discardCard(mod, true);
            });
            
            // Draw cards equal to what was played
            for (let i = 0; i < cardsPlayed; i++) {
                gameState.drawCard(true);
            }
            
            // Display player's defense cards in the center (below enemy attack cards)
            this.playerPlayedCards.forEach(card => card.destroy());
            this.playerPlayedCards = this.displayPlayedCards(this.defendingCards, 400, true);
            this.updateBattleStatsUI();
        } else {
            // No block
            this.defendingCards = null;
            
            // Clear any displayed player cards since no defense
            this.playerPlayedCards.forEach(card => card.destroy());
            this.playerPlayedCards = [];
        }
        
        this.selectedCreature = null;
        this.selectedElement = null;
        this.selectedModifiers = [];
        
        this.time.delayedCall(500, () => {
            this.resolveEnemyCombat();
        });
    }
    
    resolveEnemyCombat() {
        // Calculate attack
        let totalAttack = this.attackingCards.creature.baseStats.attack;
        this.attackingCards.modifiers.forEach(mod => {
            if (mod.type === 'attack_modifier') {
                totalAttack += mod.modifier;
            }
        });
        
        // Check elemental counter rules
        let canDefend = true;
        let defenseMessage = '';
        
        const attackElement = this.attackingCards.element?.id;
        const defendElement = this.defendingCards?.element?.id;
        
        if (attackElement && this.defendingCards && this.defendingCards.creature) {
            // Attacker has an element - check if defender can block
            if (!defendElement) {
                // Defender has no element - cannot block elemental attacks
                canDefend = false;
                defenseMessage = 'ELEMENTAL ATTACK!\nNo counter element!';
            } else {
                // Check element counter pairings
                if (ELEMENT_COUNTERS[attackElement] !== defendElement) {
                    // Wrong element counter
                    canDefend = false;
                    defenseMessage = `WRONG COUNTER!\n${attackElement.toUpperCase()} needs ${ELEMENT_COUNTERS[attackElement].toUpperCase()}!`;
                }
            }
        }
        
        // Calculate defense
        let totalDefense = 0;
        if (canDefend && this.defendingCards && this.defendingCards.creature) {
            totalDefense = this.defendingCards.creature.baseStats.defense;
            this.defendingCards.modifiers.forEach(mod => {
                if (mod.type === 'defense_modifier') {
                    totalDefense += mod.modifier;
                }
            });
        }
        
        // Calculate damage
        const damage = Math.max(0, totalAttack - totalDefense);
        gameState.playerHP -= damage;
        
        if (damage > 0) {
            soundManager.playSlash();
        } else if (this.defendingCards) {
            soundManager.playBlock();
        }
        
        this.updatePlayerHP();
        
        // Show combat result in center of field
        let resultMessage = '';
        if (defenseMessage) {
            resultMessage += defenseMessage + '\n';
        }
        resultMessage += `${damage} DAMAGE!`;
        
        const resultText = this.add.text(this.cameras.main.width / 2, 400, 
            resultMessage,
            {
                fontSize: '43px',
                color: damage > 0 ? '#ff0000' : '#888888',
                fontFamily: 'Electrolize',
                fontStyle: 'bold',
                align: 'center',
                lineSpacing: 8
            }
        ).setOrigin(0.5, 0.5);
        
        this.tweens.add({
            targets: resultText,
            alpha: 0,
            y: 350,
            duration: 2000,
            ease: 'Expo.easeIn',
            onComplete: () => resultText.destroy()
        });
        
        // Check for defeat
        if (gameState.playerHP <= 0) {
            this.time.delayedCall(2000, () => {
                this.handleDefeat();
            });
            return;
        }
        
        // Clear both enemy and player played cards with animation, update hand display, then start player's turn
        this.time.delayedCall(2000, () => {
            this.clearPlayedCardsWithAnimation(() => {
                // Clear logical card tracking
                this.attackingCards = null;
                this.defendingCards = null;
                
                this.updateBattleStatsUI();
                
                // Update player's hand display before their turn starts
                this.displayHands();
                
                // Wait a moment for player to see their new hand
                this.time.delayedCall(500, () => {
                    // NOW the turn changes to player after enemy's defending phase completes
                    this.startPlayerTurn();
                });
            });
        });
    }
    
    startPlayerTurn() {
        // Increment turn counter
        this.turnCount++;
        this.turnCounterText.setText(`TURN ${this.turnCount}`);
        
        // Player can act now - it's their attacking phase
        this.setTurnHue(true);
        this.canInteractWithCards = true; // Re-enable card interaction
        
        // Turn changes to PLAYER now - their attacking phase begins
        this.currentPhase = 'ATTACKING';
        this.isDiscardMode = false;
        this.updateTurnDisplay('YOU', 'ATTACKING', 0xff4444);
        this.instructionText.setText('Select 1 Creature + Optional Element + Any Attack Modifiers');

        
        // Reset discard mode button to default state
        this.discardModeButton.setFillStyle(0x444444);
        this.discardModeButton.setAlpha(1);
        this.discardModeButton.setInteractive({ useHandCursor: true });
        this.discardModeText.setText('DISCARD'); // Reset text to "DISCARD"
        this.discardModeText.setAlpha(1);
        
        // Reset buttons for new turn
        this.actionButton.setAlpha(1);
        this.actionButtonText.setAlpha(1);
        
        // Display player's hand (important for when enemy discards)
        this.displayHands();
        this.updateActionButton();
    }
    
    updateTurnDisplay(player, phase, phaseColor) {
        // This function is kept for compatibility but doesn't change the hue
        // The hue is controlled by setTurnHue() instead
    }
    
    drawTurnGlow() {
        const { width, height } = this.cameras.main;
        const glowHeight = this.bottomHueHeight;
        const glowY = height - glowHeight;
        const cornerRadius = 100; // Increased from 40 to 100 (150% more rounding)
        
        this.turnHueGraphics.clear();
        
        // Create multiple layers with decreasing alpha for gradient/glow effect
        const layers = 5;
        for (let i = 0; i < layers; i++) {
            const alpha = 0.15 - (i * 0.025); // Fade out from 0.15 to 0.05
            const layerHeight = glowHeight - (i * 20);
            const layerY = height - layerHeight;
            
            this.turnHueGraphics.fillStyle(this.turnHueColor, alpha);
            this.turnHueGraphics.fillRoundedRect(
                0,
                layerY,
                width,
                layerHeight,
                { tl: cornerRadius, tr: cornerRadius, bl: 0, br: 0 }
            );
        }
    }
    
    setTurnHue(canPlayerAct) {
        // Update turn hue based on whether player can act
        if (canPlayerAct) {
            // Green when player can play cards
            this.turnHueColor = 0x44ff44;
        } else {
            // Red when player cannot play (enemy's turn/waiting)
            this.turnHueColor = 0xff4444;
        }
        
        // Redraw the glow with new color
        this.drawTurnGlow();
    }
    
    handleVictory() {
        soundManager.playVictory();
        
        const { width, height } = this.cameras.main;
        
        // Animate playing area cards falling off screen
        this.playerPlayedCards.forEach((card, index) => {
            card.disableInteractive();
            this.tweens.add({
                targets: card,
                y: height + 400,
                alpha: 0,
                rotation: Math.random() * 0.5 - 0.25,
                duration: 600,
                delay: index * 50,
                ease: 'Back.easeIn',
                onComplete: () => card.destroy()
            });
        });
        this.playerPlayedCards = [];
        
        this.enemyPlayedCards.forEach((card, index) => {
            card.disableInteractive();
            this.tweens.add({
                targets: card,
                y: height + 400,
                alpha: 0,
                rotation: Math.random() * 0.5 - 0.25,
                duration: 600,
                delay: index * 50,
                ease: 'Back.easeIn',
                onComplete: () => card.destroy()
            });
        });
        this.enemyPlayedCards = [];
        
        // Animate hand cards falling off screen
        if (this.handCards) {
            this.handCards.forEach((card, index) => {
                card.disableInteractive();
                this.tweens.add({
                    targets: card,
                    y: height + 400,
                    alpha: 0,
                    rotation: Math.random() * 0.5 - 0.25,
                    duration: 600,
                    delay: index * 50,
                    ease: 'Back.easeIn',
                    onComplete: () => card.destroy()
                });
            });
            this.handCards = [];
        }
        
        // Hide buttons and UI elements
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        if (this.calculationValueContainer) this.calculationValueContainer.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        // Hide battle stat icons
        if (this.playerBattleStat) this.playerBattleStat.setAlpha(0);
        if (this.enemyBattleStat) this.enemyBattleStat.setAlpha(0);
        
        // Show victory message with per-letter animation
        const victoryMessage = 'VICTORY!';
        this.victoryTextContainer = this.add.container(width / 2, height / 2 - 100);
        this.victoryLetters = [];
        
        // First pass: create all letters and measure total width
        const tempVictoryLetters = [];
        let victoryTotalWidth = 0;
        
        for (let i = 0; i < victoryMessage.length; i++) {
            const char = victoryMessage[i];
            const tempLetter = this.add.text(0, 0, char, {
                fontSize: '120px',
                color: '#00ff00',
                fontFamily: 'Electrolize',
                fontStyle: 'bold',
                stroke: '#000000',
                strokeThickness: 8
            });
            tempVictoryLetters.push(tempLetter);
            victoryTotalWidth += tempLetter.width;
        }
        
        // Second pass: position letters centered
        let victoryCurrentX = -victoryTotalWidth / 2;
        for (let i = 0; i < tempVictoryLetters.length; i++) {
            const letter = tempVictoryLetters[i];
            letter.setPosition(victoryCurrentX, 0);
            letter.setOrigin(0, 0.5);
            letter.letterIndex = i;
            
            this.victoryTextContainer.add(letter);
            this.victoryLetters.push(letter);
            
            victoryCurrentX += letter.width;
        }
        
        this.time.delayedCall(1500, () => {
            // Play Again button
            const playAgainButton = this.add.rectangle(width / 2, height / 2 + 100, 500, 100, 0x00aa00);
            playAgainButton.setStrokeStyle(4, 0xffffff);
            playAgainButton.setInteractive({ useHandCursor: true });
            
            const playAgainText = this.add.text(width / 2, height / 2 + 100, 'PLAY AGAIN', {
                fontSize: '48px',
                color: '#ffffff',
                fontFamily: 'Electrolize',
                fontStyle: 'bold'
            }).setOrigin(0.5);
            
            playAgainButton.on('pointerdown', () => {
                soundManager.playClick();
                gameState.reset();
                this.scene.start('DraftScene');
            });
        });
    }
    
    handleDefeat() {
        soundManager.playDefeat();
        
        const { width, height } = this.cameras.main;
        
        // Animate playing area cards falling off screen
        this.playerPlayedCards.forEach((card, index) => {
            card.disableInteractive();
            this.tweens.add({
                targets: card,
                y: height + 400,
                alpha: 0,
                rotation: Math.random() * 0.5 - 0.25,
                duration: 600,
                delay: index * 50,
                ease: 'Back.easeIn',
                onComplete: () => card.destroy()
            });
        });
        this.playerPlayedCards = [];
        
        this.enemyPlayedCards.forEach((card, index) => {
            card.disableInteractive();
            this.tweens.add({
                targets: card,
                y: height + 400,
                alpha: 0,
                rotation: Math.random() * 0.5 - 0.25,
                duration: 600,
                delay: index * 50,
                ease: 'Back.easeIn',
                onComplete: () => card.destroy()
            });
        });
        this.enemyPlayedCards = [];
        
        // Animate hand cards falling off screen
        if (this.handCards) {
            this.handCards.forEach((card, index) => {
                card.disableInteractive();
                this.tweens.add({
                    targets: card,
                    y: height + 400,
                    alpha: 0,
                    rotation: Math.random() * 0.5 - 0.25,
                    duration: 600,
                    delay: index * 50,
                    ease: 'Back.easeIn',
                    onComplete: () => card.destroy()
                });
            });
            this.handCards = [];
        }
        
        // Hide buttons and UI elements
        this.actionButton.setAlpha(0);
        this.actionButton.disableInteractive();
        this.actionButtonText.setAlpha(0);
        if (this.calculationValueContainer) this.calculationValueContainer.setAlpha(0);
        this.discardModeButton.setAlpha(0);
        this.discardModeButton.disableInteractive();
        this.discardModeText.setAlpha(0);
        
        // Hide battle stat icons
        if (this.playerBattleStat) this.playerBattleStat.setAlpha(0);
        if (this.enemyBattleStat) this.enemyBattleStat.setAlpha(0);
        
        // Show defeat message with per-letter animation
        const defeatMessage = 'DEFEAT!';
        this.defeatTextContainer = this.add.container(width / 2, height / 2 - 100);
        this.defeatLetters = [];
        
        // First pass: create all letters and measure total width
        const tempDefeatLetters = [];
        let defeatTotalWidth = 0;
        
        for (let i = 0; i < defeatMessage.length; i++) {
            const char = defeatMessage[i];
            const tempLetter = this.add.text(0, 0, char, {
                fontSize: '120px',
                color: '#ff4444',
                fontFamily: 'Electrolize',
                fontStyle: 'bold',
                stroke: '#000000',
                strokeThickness: 8
            });
            tempDefeatLetters.push(tempLetter);
            defeatTotalWidth += tempLetter.width;
        }
        
        // Second pass: position letters centered
        let defeatCurrentX = -defeatTotalWidth / 2;
        for (let i = 0; i < tempDefeatLetters.length; i++) {
            const letter = tempDefeatLetters[i];
            letter.setPosition(defeatCurrentX, 0);
            letter.setOrigin(0, 0.5);
            letter.letterIndex = i;
            
            this.defeatTextContainer.add(letter);
            this.defeatLetters.push(letter);
            
            defeatCurrentX += letter.width;
        }
        
        this.time.delayedCall(1500, () => {
            // Play Again button
            const playAgainButton = this.add.rectangle(width / 2, height / 2 + 100, 500, 100, 0x00aa00);
            playAgainButton.setStrokeStyle(4, 0xffffff);
            playAgainButton.setInteractive({ useHandCursor: true });
            
            const playAgainText = this.add.text(width / 2, height / 2 + 100, 'PLAY AGAIN', {
                fontSize: '48px',
                color: '#ffffff',
                fontFamily: 'Electrolize',
                fontStyle: 'bold'
            }).setOrigin(0.5);
            
            playAgainButton.on('pointerdown', () => {
                soundManager.playClick();
                gameState.reset();
                this.scene.start('DraftScene');
            });
        });
    }
    
    updateBattleStatsUI() {
        const { width, height } = this.cameras.main;
        
        // Don't reset if already visible (to prevent re-animation)
        // Only reset the one that's NOT currently being used

        // 1. Handle Attacker Stats
        if (this.attackingCards && this.attackingCards.creature) {
            const isAtk = true;
            let total = this.attackingCards.creature.baseStats.attack;
            this.attackingCards.modifiers.forEach(mod => {
                if (mod.type === 'attack_modifier') total += mod.modifier;
            });

            if (this.attackingCards.isEnemy) {
                // Enemy is attacking - animate from center (hand position) if not already visible
                if (this.enemyBattleStat.alpha === 0) {
                    this.enemyBattleStatIcon.setTexture('ui_attack');
                    this.enemyBattleStatText.setText(`${total}`);
                    
                    // Start position (from hand - center top)
                    this.enemyBattleStat.x = width / 2;
                    this.enemyBattleStat.y = 220;
                    this.enemyBattleStat.setScale(1);
                    this.enemyBattleStat.setAlpha(0.8);
                    
                    // Animate to field position
                    this.tweens.add({
                        targets: this.enemyBattleStat,
                        x: width * 0.6,
                        y: 400,
                        alpha: 1,
                        duration: 400,
                        ease: 'Cubic.easeOut'
                    });
                }
            } else {
                // Player is attacking - animate from calculation value position if not already visible
                if (this.playerBattleStat.alpha === 0) {
                    this.playerBattleStatIcon.setTexture('ui_attack');
                    this.playerBattleStatText.setText(`${total}`);
                    
                    // Start position (from calculation value display position)
                    this.playerBattleStat.x = width / 2;
                    this.playerBattleStat.y = height - 517;
                    this.playerBattleStat.setScale(1);
                    this.playerBattleStat.setAlpha(0.8);
                    
                    // Animate to field position
                    this.tweens.add({
                        targets: this.playerBattleStat,
                        x: width * 0.4,
                        y: 400,
                        alpha: 1,
                        duration: 400,
                        ease: 'Cubic.easeOut'
                    });
                }
            }
        }

        // 2. Handle Defender Stats (only in DEFENDING phase)
        if (this.currentPhase === 'DEFENDING' && this.defendingCards && this.defendingCards.creature) {
            let total = this.defendingCards.creature.baseStats.defense;
            this.defendingCards.modifiers.forEach(mod => {
                if (mod.type === 'defense_modifier') total += mod.modifier;
            });

            if (this.defendingCards.isEnemy) {
                // Enemy is defending - animate from center (hand position) if not already visible
                if (this.enemyBattleStat.alpha === 0) {
                    this.enemyBattleStatIcon.setTexture('ui_defense');
                    this.enemyBattleStatText.setText(`${total}`);
                    
                    // Start position (from hand - center top)
                    this.enemyBattleStat.x = width / 2;
                    this.enemyBattleStat.y = 220;
                    this.enemyBattleStat.setScale(1);
                    this.enemyBattleStat.setAlpha(0.8);
                    
                    // Animate to field position
                    this.tweens.add({
                        targets: this.enemyBattleStat,
                        x: width * 0.6,
                        y: 400,
                        alpha: 1,
                        duration: 400,
                        ease: 'Cubic.easeOut'
                    });
                }
            } else {
                // Player is defending - animate from calculation value position if not already visible
                if (this.playerBattleStat.alpha === 0) {
                    this.playerBattleStatIcon.setTexture('ui_defense');
                    this.playerBattleStatText.setText(`${total}`);
                    
                    // Start position (from calculation value display position)
                    this.playerBattleStat.x = width / 2;
                    this.playerBattleStat.y = height - 517;
                    this.playerBattleStat.setScale(1);
                    this.playerBattleStat.setAlpha(0.8);
                    
                    // Animate to field position
                    this.tweens.add({
                        targets: this.playerBattleStat,
                        x: width * 0.4,
                        y: 400,
                        alpha: 1,
                        duration: 400,
                        ease: 'Cubic.easeOut'
                    });
                }
            }
        }
    }

    updatePlayerHP() {
        const { width } = this.cameras.main;
        const hpQuarterCircleRadius = 105;
        const barEdgeOffset = 30;
        const playerBarStartX = barEdgeOffset;
        const playerBarEndX = width / 2; // Match the bar position - extends to center
        const playerBarWidth = playerBarEndX - playerBarStartX;
        
        // Update HP bar width immediately (depletes from right toward quarter circle)
        const hpPercent = gameState.playerHP / CONFIG.playerHP;
        const newWidth = playerBarWidth * hpPercent;
        
        // Compare using actual HP values instead of bar width
        if (gameState.playerHP < this.previousPlayerHP) {
            // HP decreased - set HP bar to new width immediately
            this.playerHPBar.width = newWidth;
            
            // Animate ghost bar catching up with a delay
            this.tweens.add({
                targets: this.playerHPGhostBar,
                width: newWidth,
                duration: 800,
                delay: 200,
                ease: 'Cubic.easeOut'
            });
        } else if (gameState.playerHP > this.previousPlayerHP) {
            // HP increased (healing) - reverse ghost effect
            // Ghost bar stays at old value, main bar animates to new value
            const oldWidth = this.playerHPBar.width;
            
            // Set ghost bar to old width (stays behind)
            this.playerHPGhostBar.width = oldWidth;
            
            // Animate main HP bar growing to new width
            this.tweens.add({
                targets: this.playerHPBar,
                width: newWidth,
                duration: 600,
                ease: 'Cubic.easeOut'
            });
            
            // Animate ghost bar catching up after a delay
            this.tweens.add({
                targets: this.playerHPGhostBar,
                width: newWidth,
                duration: 800,
                delay: 400,
                ease: 'Cubic.easeOut'
            });
        } else {
            // HP stayed the same - update both
            this.playerHPBar.width = newWidth;
            this.playerHPGhostBar.width = newWidth;
        }
        
        // Update previous HP for next comparison
        this.previousPlayerHP = gameState.playerHP;
        
        // Update HP number (clamp to 0 minimum)
        this.playerHPNumber.setText(`${Math.max(0, gameState.playerHP)}`);
    }
    
    updateEnemyHP() {
        const { width } = this.cameras.main;
        const hpQuarterCircleRadius = 105;
        const barEdgeOffset = 30;
        const enemyBarStartX = width / 2; // Match the bar position - starts at center
        const enemyBarEndX = width - barEdgeOffset;
        const enemyBarWidth = enemyBarEndX - enemyBarStartX;
        
        // Update HP bar width and position (depletes from left to right toward quarter circle)
        const hpPercent = gameState.enemyHP / CONFIG.enemyHP;
        const newWidth = enemyBarWidth * hpPercent;
        const newX = enemyBarStartX + (enemyBarWidth * (1 - hpPercent));
        
        // Compare using actual HP values instead of bar width
        if (gameState.enemyHP < this.previousEnemyHP) {
            // HP decreased - set HP bar to new width and position immediately
            this.enemyHPBar.width = newWidth;
            this.enemyHPBar.x = newX;
            
            // Animate ghost bar catching up with a delay
            this.tweens.add({
                targets: this.enemyHPGhostBar,
                width: newWidth,
                x: newX,
                duration: 800,
                delay: 200,
                ease: 'Cubic.easeOut'
            });
        } else if (gameState.enemyHP > this.previousEnemyHP) {
            // HP increased (healing) - reverse ghost effect
            // Ghost bar stays at old value, main bar animates to new value
            const oldWidth = this.enemyHPBar.width;
            const oldX = this.enemyHPBar.x;
            
            // Set ghost bar to old width and position (stays behind)
            this.enemyHPGhostBar.width = oldWidth;
            this.enemyHPGhostBar.x = oldX;
            
            // Animate main HP bar growing to new width and position
            this.tweens.add({
                targets: this.enemyHPBar,
                width: newWidth,
                x: newX,
                duration: 600,
                ease: 'Cubic.easeOut'
            });
            
            // Animate ghost bar catching up after a delay
            this.tweens.add({
                targets: this.enemyHPGhostBar,
                width: newWidth,
                x: newX,
                duration: 800,
                delay: 400,
                ease: 'Cubic.easeOut'
            });
        } else {
            // HP stayed the same - update both
            this.enemyHPBar.width = newWidth;
            this.enemyHPBar.x = newX;
            this.enemyHPGhostBar.width = newWidth;
            this.enemyHPGhostBar.x = newX;
        }
        
        // Update previous HP for next comparison
        this.previousEnemyHP = gameState.enemyHP;
        
        // Update HP number (clamp to 0 minimum)
        this.enemyHPNumber.setText(`${Math.max(0, gameState.enemyHP)}`);
    }
    
    clearPlayedCardsWithAnimation(callback) {
        const { width } = this.cameras.main;
        
        // Animate enemy cards sliding off to the right
        this.enemyPlayedCards.forEach((card, index) => {
            this.tweens.add({
                targets: card,
                x: width + 200,
                duration: 400,
                delay: index * 50,
                ease: 'Back.easeIn',
                onComplete: () => {
                    card.destroy();
                }
            });
        });
        
        // Animate player cards sliding off to the left
        this.playerPlayedCards.forEach((card, index) => {
            this.tweens.add({
                targets: card,
                x: -200,
                duration: 400,
                delay: index * 50,
                ease: 'Back.easeIn',
                onComplete: () => {
                    card.destroy();
                }
            });
        });
        
        // Animate enemy battle stat icon off to the right
        if (this.enemyBattleStat && this.enemyBattleStat.alpha > 0) {
            this.tweens.add({
                targets: this.enemyBattleStat,
                x: width + 200,
                alpha: 0,
                duration: 400,
                ease: 'Back.easeIn',
                onComplete: () => {
                    this.enemyBattleStat.setAlpha(0);
                    // Reset position for next use
                    this.enemyBattleStat.x = width * 0.6;
                }
            });
        }
        
        // Animate player battle stat icon off to the left
        if (this.playerBattleStat && this.playerBattleStat.alpha > 0) {
            this.tweens.add({
                targets: this.playerBattleStat,
                x: -200,
                alpha: 0,
                duration: 400,
                ease: 'Back.easeIn',
                onComplete: () => {
                    this.playerBattleStat.setAlpha(0);
                    // Reset position for next use
                    this.playerBattleStat.x = width * 0.4;
                }
            });
        }
        
        // Clear arrays
        this.enemyPlayedCards = [];
        this.playerPlayedCards = [];
        
        // Call callback after animation completes
        if (callback) {
            const maxDelay = Math.max(this.enemyPlayedCards.length, this.playerPlayedCards.length) * 50;
            this.time.delayedCall(400 + maxDelay, callback);
        }
    }
    
    update(time, delta) {
        // Animate instruction text with per-letter bobbing
        if (this.instructionLetters && this.instructionLetters.length > 0) {
            for (let i = 0; i < this.instructionLetters.length; i++) {
                const letter = this.instructionLetters[i];
                
                // Create subtle wave effect - each letter offset by its position
                // Wave parameters: amplitude = 2px, frequency = 0.002 (slow), phase = 0.3 (spacing between letters)
                const offset = Math.sin(time * 0.002 + i * 0.3) * 2;
                
                letter.y = offset;
            }
        }
        
        // Animate victory text with per-letter bobbing
        if (this.victoryLetters && this.victoryLetters.length > 0) {
            for (let i = 0; i < this.victoryLetters.length; i++) {
                const letter = this.victoryLetters[i];
                const offset = Math.sin(time * 0.002 + i * 0.3) * 2;
                letter.y = offset;
            }
        }
        
        // Animate defeat text with per-letter bobbing
        if (this.defeatLetters && this.defeatLetters.length > 0) {
            for (let i = 0; i < this.defeatLetters.length; i++) {
                const letter = this.defeatLetters[i];
                const offset = Math.sin(time * 0.002 + i * 0.3) * 2;
                letter.y = offset;
            }
        }
    }
}
