// Global game state for roguelite progression

class GameState {
    constructor() {
        this.reset();
    }
    
    reset() {
        this.playerDeck = []; // Full deck of cards
        this.playerHand = []; // Current hand
        this.playerDiscard = []; // Discard pile
        
        this.enemyDeck = [];
        this.enemyHand = [];
        this.enemyDiscard = [];
        
        this.playerHP = 100;
        this.enemyHP = 100;
        
        this.currentBattle = 0;
        this.totalBattles = 5;
        this.wins = 0;
        this.losses = 0;
        
        this.isPlayerTurn = true;
    }
    
    createStartingDeck() {
        // Create deck with ALL available cards (one copy of each)
        const deck = [];
        
        // Add ALL creatures (8 total)
        const creatures = Object.values(window.CREATURE_CARDS || {});
        creatures.forEach(creature => {
            deck.push({ ...creature });
        });
        
        // Add ALL elements (4 total)
        const elements = Object.values(window.ELEMENT_CARDS || {});
        elements.forEach(element => {
            deck.push({ ...element });
        });
        
        // Add ALL attack modifiers (3 total)
        const attackMods = Object.values(window.ATTACK_MODIFIER_CARDS || {});
        attackMods.forEach(mod => {
            deck.push({ ...mod });
        });
        
        // Add ALL defense modifiers (4 total)
        const defenseMods = Object.values(window.DEFENSE_MODIFIER_CARDS || {});
        defenseMods.forEach(mod => {
            deck.push({ ...mod });
        });
        
        // Add ALL healing cards (2 total)
        const healingCards = Object.values(window.HEALING_CARDS || {});
        healingCards.forEach(healing => {
            deck.push({ ...healing });
        });
        
        // Total: 8 creatures + 4 elements + 3 attack + 4 defense + 2 healing = 21 cards
        return Phaser.Utils.Array.Shuffle(deck);
    }
    
    drawCard(isPlayer = true) {
        const deck = isPlayer ? this.playerDeck : this.enemyDeck;
        const hand = isPlayer ? this.playerHand : this.enemyHand;
        const discard = isPlayer ? this.playerDiscard : this.enemyDiscard;
        
        // If deck is empty, shuffle discard into deck
        if (deck.length === 0 && discard.length > 0) {
            while (discard.length > 0) {
                deck.push(discard.pop());
            }
            Phaser.Utils.Array.Shuffle(deck);
        }
        
        // Draw a card
        if (deck.length > 0) {
            const card = deck.pop();
            hand.push(card);
            return card;
        }
        
        return null;
    }
    
    discardCard(card, isPlayer = true) {
        const hand = isPlayer ? this.playerHand : this.enemyHand;
        const discard = isPlayer ? this.playerDiscard : this.enemyDiscard;
        
        const index = hand.indexOf(card);
        if (index > -1) {
            hand.splice(index, 1);
            discard.push(card);
        }
    }
    
    nextBattle() {
        this.currentBattle++;
        return this.currentBattle < this.totalBattles;
    }
    
    recordWin() {
        this.wins++;
    }
    
    recordLoss() {
        this.losses++;
    }
}

// Singleton instance
export const gameState = new GameState();
