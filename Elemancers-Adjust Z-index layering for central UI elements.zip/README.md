# Elemental Fusion - Card Roguelite

A turn-based card battler where players use creatures, elements, and modifiers to defeat opponents in tactical combat.

## Game Flow

1. **Deck Building**: Both players start with a deck of 16 random cards (creatures, elements, attack/defense modifiers)
2. **Starting Hand**: Each player draws 5 cards
3. **Turn-Based Combat**: Players alternate attacking and defending until one reaches 0 HP
4. **Progression**: Win 5 battles to complete a run

## Turn Structure

Each turn consists of two phases:

### Attacking Phase
You have two options on your turn:

**Option 1: Attack**
- Select 1 creature card (required)
- Optionally add 1 element card
- Optionally add any number of attack modifier cards
- Click "ATTACK!" to proceed
- **You immediately draw the same number of cards you played**
- You can see what cards the enemy plays to defend

**Option 2: Discard & Pass**
- Click "SWITCH TO DISCARD MODE" (bottom left)
- Select any number of cards from your hand
- Click "DISCARD & PASS" to discard them
- **You immediately draw the same number of cards you discarded**
- Your turn ends and passes to the opponent

### Defending Phase  
- You can see what cards the enemy is attacking with
- Select 1 creature (optional) to block
- Optionally add 1 element card
- Optionally add any number of defense modifier cards
- Click "DEFEND!" to block, or "NO BLOCK" to take full damage
- **You immediately draw the same number of cards you played**
- Turn passes to opponent

## Combat Resolution

**Damage = Total Attack - Total Defense**

- Total Attack = Creature's attack stat + attack modifier bonuses
- Total Defense = Creature's defense stat + defense modifier bonuses
- If defense >= attack, no damage is dealt
- Damage is dealt to the defending player's HP

## Card Types

### Creature Cards
All creatures have complete fusion artwork and custom pixel art:
- **Blazing Scarf**: ATK 16 / DEF 9 - Fiery spirit
- **Planted Pot**: ATK 10 / DEF 16 - Growing guardian
- **Rock Gem**: ATK 13 / DEF 13 - Crystalline defender
- **Painguin**: ATK 14 / DEF 11 - Painful penguin
- **Bicosis**: ATK 11 / DEF 14 - Tentacled terror
- **Shoutout**: ATK 17 / DEF 8 - Vocal powerhouse

### Element Cards
- **Fire**: Burn effect (coming soon)
- **Water**: Flow effect (coming soon)
- **Stone**: Fortify effect (coming soon)
- **Wood**: Growth effect (coming soon)

*Elements currently provide no stat bonuses - they will trigger special effects in future updates*

### Attack Modifier Cards
- **Sharp Claws**: +5 Attack
- **Battle Cry**: +3 Attack

### Defense Modifier Cards
- **Thick Hide**: +5 Defense
- **Iron Scales**: +3 Defense

## AI Fusion System

When you play a creature with an element card, the game displays unique pre-generated fusion artwork showing the combined form!

### Complete Fusion Collection

All 24 creature + element combinations have unique artwork:

**🔥 Blazing Scarf Fusions:**
- Fire: Magma rock scarf with glowing molten cracks
- Water: Flowing aqua fabric with water effects  
- Stone: Hardened lava rock texture with fire gems
- Wood: Living wooden branches with leaves and flames

**🌱 Planted Pot Fusions:**
- Fire: Burning plant with enhanced ceramic pot
- Water: Water-form pot with aquatic lily
- Stone: Granite pot with crystalline bonsai tree
- Wood: Natural growth enhancement

**💎 Rock Gem Fusions:**
- Fire: Volcanic gem with internal flames and lava
- Water: Crystalline water formation
- Stone: Enhanced multi-layered gemstone
- Wood: Petrified wood crystal with moss and tree rings

**🐧 Painguin Fusions:**
- Fire: Flames on feathers/body
- Water: Aquatic ice penguin form
- Stone: Crystalline rock penguin
- Wood: Natural branch/leaf penguin

**🐙 Bicosis Fusions:**
- Fire: Burning tentacle blob with flames
- Water: Water elemental blob form
- Stone: Rocky crystalline tentacle
- Wood: Vine and leaf covered blob

**👅 Shoutout Fusions:**
- Fire: Flame-tongue creature with fire
- Water: Aquatic form with water tongue
- Stone: Rocky armored creature
- Wood: Nature-infused creature with plant tongue

### Visual Experience

When you or the enemy trigger a fusion:
1. **Loading Animation**: "FUSING..." text with progress bar and animated sparks
2. **Particle Explosion**: Spectacular burst effect when fusion is revealed
   - 30 colored particles bursting outward
   - Bright white flash
   - 3 expanding golden rings
   - 12 spinning star particles
3. **Fusion Display**: The combined artwork replaces individual cards during combat
4. **Combat Resolution**: The fusion creature attacks/defends with combined stats

**Fusions work for:**
- Your attacking cards (creature + element)
- Your defending cards (creature + element)
- Enemy attacking cards (creature + element)
- Enemy defending cards (creature + element)

The fusion artwork makes each creature + element combination visually unique and exciting!

## Customization

You can easily add your own card art by:
1. Providing creature card images (pixel art style recommended)
2. Updating the `CREATURE_CARDS` in `config.js` with `imageUrl` property
3. New creatures with `imageUrl` will automatically trigger AI fusion when combined with elements/modifiers

Example:
```javascript
BLAZING_SCARF: {
    id: 'blazing_scarf',
    name: 'Blazing Scarf',
    imageUrl: 'https://your-image-url.png',
    // ... other properties
}
```

## Game Files

- `main.js` - Game initialization
- `config.js` - Card data and game constants
- `GameState.js` - Roguelite progression state
- `Card.js` - Card visual component
- `FusionGenerator.js` - AI image generation for card fusions
- `SoundManager.js` - Procedural audio effects
- `MenuScene.js` - Main menu
- `DraftScene.js` - Initial deck building
- `BattleScene.js` - Turn-based combat with AI fusion
- `VictoryScene.js` - Run completion
- `GameOverScene.js` - Run failure
