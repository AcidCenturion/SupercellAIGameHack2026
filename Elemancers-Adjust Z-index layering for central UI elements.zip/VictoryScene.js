import Phaser from 'phaser';
import { gameState } from './GameState.js';

export default class VictoryScene extends Phaser.Scene {
    constructor() {
        super({ key: 'VictoryScene' });
    }
    
    create() {
        const { width, height } = this.cameras.main;
        
        // Victory banner
        const title = this.add.text(width / 2, 300, 'RUN COMPLETE!', {
            fontSize: '72px',
            color: '#ffcc00',
            fontFamily: 'Press Start 2P',
            stroke: '#000000',
            strokeThickness: 10
        });
        title.setOrigin(0.5);
        
        // Create simple celebratory graphics
        const graphics = this.add.graphics();
        graphics.fillStyle(0xffcc00, 1);
        
        // Create falling stars animation
        for (let i = 0; i < 20; i++) {
            this.time.delayedCall(i * 100, () => {
                const star = this.add.circle(
                    Phaser.Math.Between(width * 0.3, width * 0.7),
                    -50,
                    10,
                    0xffcc00
                );
                
                this.tweens.add({
                    targets: star,
                    y: height + 50,
                    x: star.x + Phaser.Math.Between(-100, 100),
                    alpha: 0,
                    duration: 2000,
                    ease: 'Cubic.easeIn'
                });
            });
        }
        
        // Stats
        const stats = this.add.text(width / 2, 500, 
            `Battles Won: ${gameState.totalBattles}\n\nTotal Runs Won: ${gameState.wins}`,
            {
                fontSize: '32px',
                color: '#ffffff',
                fontFamily: 'Arial',
                align: 'center',
                lineSpacing: 15
            }
        );
        stats.setOrigin(0.5);
        
        // Message
        const message = this.add.text(width / 2, 650, 
            'You mastered the art of Elemental Fusion!',
            {
                fontSize: '24px',
                color: '#aaaaaa',
                fontFamily: 'Arial',
                align: 'center'
            }
        );
        message.setOrigin(0.5);
        
        // Return to menu button
        const menuButton = this.add.rectangle(width / 2, 850, 400, 70, 0x0066cc);
        menuButton.setStrokeStyle(4, 0xffffff);
        menuButton.setInteractive({ useHandCursor: true });
        
        const menuText = this.add.text(width / 2, 850, 'MAIN MENU', {
            fontSize: '28px',
            color: '#ffffff',
            fontFamily: 'Press Start 2P'
        });
        menuText.setOrigin(0.5);
        
        menuButton.on('pointerover', () => {
            menuButton.setFillStyle(0x0088ff);
        });
        
        menuButton.on('pointerout', () => {
            menuButton.setFillStyle(0x0066cc);
        });
        
        menuButton.on('pointerdown', () => {
            this.scene.start('MenuScene');
        });
    }
}
