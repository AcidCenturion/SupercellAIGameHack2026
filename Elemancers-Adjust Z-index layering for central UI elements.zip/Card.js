import Phaser from 'phaser';

// Card class for visual representation
export default class Card extends Phaser.GameObjects.Container {
    constructor(scene, x, y, cardData, imageUrl = null, elementColor = null) {
        super(scene, x, y);
        
        this.cardData = cardData;
        this.imageUrl = imageUrl;
        this.elementColor = elementColor;
        this.borderColor = null; // Will be set in createCard
        
        console.log('Card created - imageUrl:', imageUrl, 'cardData.imageUrl:', cardData.imageUrl, 'elementColor:', elementColor);
        
        this.createCard();
        scene.add.existing(this);
    }
    
    createCard() {
        const cardWidth = 240;
        const cardHeight = 320;
        
        // Determine colors based on fusion status
        let bgStrokeColor, imageAreaColor;
        
        if (this.elementColor !== null) {
            // Fusion card - use element color for both border and image area
            bgStrokeColor = this.elementColor;
            imageAreaColor = this.elementColor;
        } else if (this.cardData.type === 'creature' && this.cardData.imageUrl) {
            // Unfused creature with base image - use very light whitish gray
            bgStrokeColor = 0xeeeeee;
            imageAreaColor = 0xdddddd;
        } else {
            // Other cards (elements, modifiers without images) - use card color
            bgStrokeColor = this.cardData.color || 0xffffff;
            imageAreaColor = this.cardData.color || 0x555555;
        }
        
        // Store the border color for use in highlight method
        this.borderColor = bgStrokeColor;
        
        // Card background - always dark for contrast
        const bg = this.scene.add.rectangle(0, 0, cardWidth, cardHeight, 0x2a2a2a);
        bg.setStrokeStyle(4, bgStrokeColor);
        this.add(bg);
        
        // Card image area
        const imageAreaSize = 200; // Square image area
        const imageArea = this.scene.add.rectangle(0, -50, imageAreaSize, imageAreaSize, imageAreaColor);
        imageArea.setStrokeStyle(3, 0x000000); // Black border around image area
        this.add(imageArea);
        
        // If we have a generated or uploaded image, display it
        if (this.imageUrl) {
            // Load and display the generated image
            const key = 'card_' + Date.now() + Math.random();
            this.scene.load.image(key, this.imageUrl);
            this.scene.load.once('complete', () => {
                const img = this.scene.add.image(0, -50, key);
                img.setDisplaySize(imageAreaSize, imageAreaSize);
                this.add(img);
            });
            this.scene.load.start();
        } else if (this.cardData.imageUrl) {
            // Use the creature's base uploaded image
            const key = 'card_' + Date.now() + Math.random();
            this.scene.load.image(key, this.cardData.imageUrl);
            this.scene.load.once('complete', () => {
                const img = this.scene.add.image(0, -50, key);
                img.setDisplaySize(imageAreaSize, imageAreaSize);
                this.add(img);
            });
            this.scene.load.start();
        } else {
            // Placeholder icon for base cards without images
            const iconText = this.scene.add.text(0, -50, 
                this.cardData.type === 'creature' ? '🐾' : '✦',
                { fontSize: '64px' }
            );
            iconText.setOrigin(0.5);
            this.add(iconText);
        }
        
        // Card name
        const nameText = this.scene.add.text(0, 70, this.cardData.name, {
            fontSize: '22px',
            color: '#ffffff',
            fontFamily: 'Electrolize',
            fontStyle: 'bold',
            wordWrap: { width: cardWidth - 20 }
        });
        nameText.setOrigin(0.5);
        this.add(nameText);
        
        // Card stats (for creatures)
        if (this.cardData.baseStats || this.cardData.stats) {
            const stats = this.cardData.baseStats || this.cardData.stats;
            
            if (stats.attack !== undefined && stats.defense !== undefined) {
                // Create a container for stats with icons
                const statsContainer = this.scene.add.container(0, 105);
                
                // Load attack icon
                const attackIconKey = 'ui_attack_' + Date.now() + Math.random();
                this.scene.load.image(attackIconKey, 'https://rosebud.ai/assets/ui_attack.png?hBKz');
                
                // Load defense icon
                const defenseIconKey = 'ui_defense_' + Date.now() + Math.random();
                this.scene.load.image(defenseIconKey, 'https://rosebud.ai/assets/ui_defense.png?RI2H');
                
                this.scene.load.once('complete', () => {
                    // Attack icon and number
                    const attackIcon = this.scene.add.image(0, 0, attackIconKey);
                    attackIcon.setDisplaySize(20, 20);
                    
                    const attackText = this.scene.add.text(12, 0, Math.floor(stats.attack).toString(), {
                        fontSize: '18px',
                        color: '#ffcc00',
                        fontFamily: 'Electrolize',
                        fontStyle: 'bold'
                    });
                    attackText.setOrigin(0, 0.5);
                    
                    // Defense icon and number (offset to the right)
                    const defenseIcon = this.scene.add.image(50, 0, defenseIconKey);
                    defenseIcon.setDisplaySize(20, 20);
                    
                    const defenseText = this.scene.add.text(62, 0, Math.floor(stats.defense).toString(), {
                        fontSize: '18px',
                        color: '#ffcc00',
                        fontFamily: 'Electrolize',
                        fontStyle: 'bold'
                    });
                    defenseText.setOrigin(0, 0.5);
                    
                    // Add all to container
                    statsContainer.add([attackIcon, attackText, defenseIcon, defenseText]);
                    
                    // Center the container based on total width
                    const totalWidth = 62 + defenseText.width;
                    statsContainer.x = -totalWidth / 2 + 10;
                });
                
                this.scene.load.start();
                this.add(statsContainer);
            } else {
                const statsText = this.scene.add.text(0, 105, 
                    `${this.cardData.description}`,
                    { fontSize: '16px', color: '#ffcc00', fontFamily: 'Electrolize', fontStyle: 'bold' }
                );
                statsText.setOrigin(0.5);
                this.add(statsText);
            }
        }
        
        // Card modifier (for attack/defense modifiers)
        if (this.cardData.modifier !== undefined && this.cardData.type !== 'element') {
            if (this.cardData.type === 'attack_modifier') {
                // Attack modifier with icon
                const modContainer = this.scene.add.container(0, 105);
                
                // Load attack icon
                const attackIconKey = 'ui_attack_mod_' + Date.now() + Math.random();
                this.scene.load.image(attackIconKey, 'https://rosebud.ai/assets/ui_attack.png?hBKz');
                
                this.scene.load.once('complete', () => {
                    // Effect number
                    const effectText = this.scene.add.text(-15, 0, 
                        this.cardData.effect || `${this.cardData.modifier > 0 ? '+' : ''}${this.cardData.modifier}`,
                        { fontSize: '32px', color: '#ffff00', fontFamily: 'Electrolize', fontStyle: 'bold' }
                    );
                    effectText.setOrigin(1, 0.5);
                    
                    // Attack icon next to number
                    const attackIcon = this.scene.add.image(5, 0, attackIconKey);
                    attackIcon.setDisplaySize(28, 28);
                    
                    modContainer.add([effectText, attackIcon]);
                });
                
                this.scene.load.start();
                this.add(modContainer);
            } else if (this.cardData.type === 'defense_modifier') {
                // Defense modifier with icon
                const modContainer = this.scene.add.container(0, 105);
                
                // Load defense icon
                const defenseIconKey = 'ui_defense_mod_' + Date.now() + Math.random();
                this.scene.load.image(defenseIconKey, 'https://rosebud.ai/assets/ui_defense.png?RI2H');
                
                this.scene.load.once('complete', () => {
                    // Effect number
                    const effectText = this.scene.add.text(-15, 0, 
                        this.cardData.effect || `${this.cardData.modifier > 0 ? '+' : ''}${this.cardData.modifier}`,
                        { fontSize: '32px', color: '#ffff00', fontFamily: 'Electrolize', fontStyle: 'bold' }
                    );
                    effectText.setOrigin(1, 0.5);
                    
                    // Defense icon next to number
                    const defenseIcon = this.scene.add.image(5, 0, defenseIconKey);
                    defenseIcon.setDisplaySize(28, 28);
                    
                    modContainer.add([effectText, defenseIcon]);
                });
                
                this.scene.load.start();
                this.add(modContainer);
            } else {
                // Other modifiers (fallback)
                const modText = this.scene.add.text(0, 105, 
                    `${this.cardData.modifier > 0 ? '+' : ''}${this.cardData.modifier}`,
                    { fontSize: '32px', color: '#ffff00', fontFamily: 'Electrolize', fontStyle: 'bold' }
                );
                modText.setOrigin(0.5);
                this.add(modText);
            }
        }
        
        // Healing value (for healing cards)
        if (this.cardData.healing !== undefined) {
            const healContainer = this.scene.add.container(0, 105);
            
            // Load health icon
            const healthIconKey = 'ui_health_' + Date.now() + Math.random();
            this.scene.load.image(healthIconKey, 'https://rosebud.ai/assets/ui_health.png?GPuC');
            
            this.scene.load.once('complete', () => {
                // Effect number
                const effectText = this.scene.add.text(-15, 0, 
                    this.cardData.effect || `+${this.cardData.healing}`,
                    { fontSize: '32px', color: '#00ff66', fontFamily: 'Electrolize', fontStyle: 'bold' }
                );
                effectText.setOrigin(1, 0.5);
                
                // Health icon next to number
                const healthIcon = this.scene.add.image(5, 0, healthIconKey);
                healthIcon.setDisplaySize(28, 28);
                
                healContainer.add([effectText, healthIcon]);
            });
            
            this.scene.load.start();
            this.add(healContainer);
        }
        
        // Card description (use flavorText for modifiers and healing cards, description for others)
        const hasFlavorText = this.cardData.type === 'attack_modifier' || 
                             this.cardData.type === 'defense_modifier' || 
                             this.cardData.type === 'healing';
        const descriptionText = hasFlavorText
            ? (this.cardData.flavorText || this.cardData.description || '')
            : (this.cardData.description || '');
            
        const descText = this.scene.add.text(0, 135, descriptionText, {
            fontSize: '13px',
            color: '#cccccc',
            fontFamily: 'Electrolize',
            fontStyle: hasFlavorText ? 'italic' : 'normal',
            wordWrap: { width: cardWidth - 20 },
            align: 'center'
        });
        descText.setOrigin(0.5);
        this.add(descText);
        
        // Make the entire container interactive
        // The hit area needs to be centered at 0,0 since card elements are positioned relative to center
        this.setSize(cardWidth, cardHeight);
        bg.setInteractive();
        
        // Forward events from background to container
        bg.on('pointerdown', (pointer) => {
            this.emit('pointerdown', pointer, this);
        });
        bg.on('pointerover', (pointer) => {
            this.emit('pointerover', pointer, this);
        });
        bg.on('pointerout', (pointer) => {
            this.emit('pointerout', pointer, this);
        });
    }
    
    highlight(enable) {
        const bg = this.list[0];
        if (enable) {
            bg.setStrokeStyle(6, 0xffff00);
            this.setScale(1.1);
        } else {
            bg.setStrokeStyle(4, this.borderColor);
            this.setScale(1);
        }
    }
}
