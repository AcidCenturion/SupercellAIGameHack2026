import Phaser from 'phaser';
import { CREATURE_CARDS, ELEMENT_CARDS, ATTACK_MODIFIER_CARDS, DEFENSE_MODIFIER_CARDS, HEALING_CARDS, CONFIG } from './config.js';
import { gameState } from './GameState.js';
import { soundManager } from './SoundManager.js';

export default class DraftScene extends Phaser.Scene {
    constructor() {
        super({ key: 'DraftScene' });
    }
    
    create() {
        const { width, height } = this.cameras.main;
        
        // Make card data available globally for GameState
        window.CREATURE_CARDS = CREATURE_CARDS;
        window.ELEMENT_CARDS = ELEMENT_CARDS;
        window.ATTACK_MODIFIER_CARDS = ATTACK_MODIFIER_CARDS;
        window.DEFENSE_MODIFIER_CARDS = DEFENSE_MODIFIER_CARDS;
        window.HEALING_CARDS = HEALING_CARDS;
        
        // Title
        const title = this.add.text(width / 2, 300, 'PREPARING FOR BATTLE', {
            fontSize: '64px',
            color: '#ffcc00',
            fontFamily: 'Press Start 2P'
        });
        title.setOrigin(0.5);
        
        const instruction = this.add.text(width / 2, 450, 
            'Building your deck...',
            {
                fontSize: '32px',
                color: '#ffffff',
                fontFamily: 'Electrolize'
            }
        );
        instruction.setOrigin(0.5);
        
        // Clear hands and discard piles from previous battle
        gameState.playerHand = [];
        gameState.playerDiscard = [];
        gameState.enemyHand = [];
        gameState.enemyDiscard = [];
        
        // Create starting decks for both players
        gameState.playerDeck = gameState.createStartingDeck();
        gameState.enemyDeck = gameState.createStartingDeck();
        
        // Debug: Check if imageUrls are preserved
        console.log('Player deck after creation:', gameState.playerDeck);
        const creaturesWithImages = gameState.playerDeck.filter(c => c.type === 'creature' && c.imageUrl);
        console.log('Creatures with imageUrl in deck:', creaturesWithImages);
        
        // Reset HP
        gameState.playerHP = CONFIG.playerHP;
        gameState.enemyHP = CONFIG.enemyHP;
        
        // Draw starting hands
        for (let i = 0; i < CONFIG.startingHandSize; i++) {
            gameState.drawCard(true); // Player
            gameState.drawCard(false); // Enemy
        }
        
        const statusText = this.add.text(width / 2, 600, 
            `✓ Deck created (${gameState.playerDeck.length + CONFIG.startingHandSize} cards)\n✓ Starting hand drawn (${gameState.playerHand.length} cards)\n✓ Ready for battle!`,
            {
                fontSize: '24px',
                color: '#00ff00',
                fontFamily: 'Electrolize',
                align: 'center',
                lineSpacing: 15
            }
        );
        statusText.setOrigin(0.5);
        
        // Auto-continue after a moment
        this.time.delayedCall(2000, () => {
            soundManager.playClick();
            this.scene.start('BattleScene');
        });
    }
}
