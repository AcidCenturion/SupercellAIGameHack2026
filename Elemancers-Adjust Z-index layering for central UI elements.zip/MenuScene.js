import Phaser from 'phaser';
import { gameState } from './GameState.js';
import { soundManager } from './SoundManager.js';

export default class MenuScene extends Phaser.Scene {
    constructor() {
        super({ key: 'MenuScene' });
    }
    
    create() {
        const { width, height } = this.cameras.main;
        
        // Title
        const title = this.add.text(width / 2, 250, 'ELEMENTAL FUSION', {
            fontSize: '72px',
            color: '#ffcc00',
            fontFamily: 'Press Start 2P',
            stroke: '#000000',
            strokeThickness: 8
        });
        title.setOrigin(0.5);
        
        // Subtitle
        const subtitle = this.add.text(width / 2, 370, 'Card Roguelite', {
            fontSize: '32px',
            color: '#ffffff',
            fontFamily: 'Press Start 2P'
        });
        subtitle.setOrigin(0.5);
        
        // Instructions
        const instructions = this.add.text(width / 2, 500, 
            'Combine Creature + Element cards\nto create powerful fusion cards!\n\nBattle through 5 enemies to win the run',
            {
                fontSize: '20px',
                color: '#cccccc',
                fontFamily: 'Arial',
                align: 'center',
                lineSpacing: 10
            }
        );
        instructions.setOrigin(0.5);
        
        // Start button
        const startButton = this.add.rectangle(width / 2, 700, 400, 80, 0x00aa00);
        startButton.setStrokeStyle(4, 0xffffff);
        startButton.setInteractive({ useHandCursor: true });
        
        const startText = this.add.text(width / 2, 700, 'START RUN', {
            fontSize: '32px',
            color: '#ffffff',
            fontFamily: 'Press Start 2P'
        });
        startText.setOrigin(0.5);
        
        startButton.on('pointerover', () => {
            startButton.setFillStyle(0x00ff00);
        });
        
        startButton.on('pointerout', () => {
            startButton.setFillStyle(0x00aa00);
        });
        
        startButton.on('pointerdown', async () => {
            await soundManager.init();
            soundManager.playClick();
            gameState.reset();
            this.scene.start('DraftScene');
        });
        
        // Show run statistics if available
        if (gameState.wins > 0 || gameState.losses > 0) {
            const stats = this.add.text(width / 2, 900, 
                `Runs Won: ${gameState.wins} | Runs Lost: ${gameState.losses}`,
                {
                    fontSize: '18px',
                    color: '#888888',
                    fontFamily: 'Arial'
                }
            );
            stats.setOrigin(0.5);
        }
    }
}
