// Game configuration and constants

export const CONFIG = {
    width: 1920,
    height: 1080,
    
    // Card dimensions
    cardWidth: 200,
    cardHeight: 280,
    
    // Combat stats
    playerHP: 40,
    enemyHP: 40,
    
    // Roguelite progression
    battlesPerRun: 5,
    
    // Hand and deck settings
    startingHandSize: 5,
    maxHandSize: 7
};

// Base creature cards
export const CREATURE_CARDS = {
    BLAZING_SCARF: {
        id: 'blazing_scarf',
        name: 'Blazing Scarf',
        type: 'creature',
        baseStats: {
            attack: 4,
            defense: 3
        },
        description: 'Fiery spirit',
        color: 0xFF4500,
        imageUrl: 'https://rosebud.ai/assets/creature_blazing_scarf.png?Kbuc'
    },
    PLANTED_POT: {
        id: 'planted_pot',
        name: 'Planted Pot',
        type: 'creature',
        baseStats: {
            attack: 2,
            defense: 5
        },
        description: 'Growing guardian',
        color: 0x228B22,
        imageUrl: 'https://rosebud.ai/assets/creature_planted_pot.png?MNmB'
    },
    ROCK_GEM: {
        id: 'rock_gem',
        name: 'Rock Gem',
        type: 'creature',
        baseStats: {
            attack: 2,
            defense: 8
        },
        description: 'Crystalline defender',
        color: 0x808080,
        imageUrl: 'https://rosebud.ai/assets/creature_rock_gem.png?ZWcM'
    },
    PAINGUIN: {
        id: 'painguin',
        name: 'Painguin',
        type: 'creature',
        baseStats: {
            attack: 6,
            defense: 2
        },
        description: 'Painful penguin',
        color: 0x9370DB,
        imageUrl: 'https://rosebud.ai/assets/creature_painguin.png?Xmk9'
    },
    BICOSIS: {
        id: 'bicosis',
        name: 'Bicosis',
        type: 'creature',
        baseStats: {
            attack: 2,
            defense: 5
        },
        description: 'Tentacled terror',
        color: 0x32CD32,
        imageUrl: 'https://rosebud.ai/assets/creature_bicosis.png?gq4r'
    },
    SHOUTOUT: {
        id: 'shoutout',
        name: 'Shoutout',
        type: 'creature',
        baseStats: {
            attack: 3,
            defense: 4
        },
        description: 'Vocal powerhouse',
        color: 0xFF1493,
        imageUrl: 'https://rosebud.ai/assets/creature_shoutout.png?2vff'
    },
    REJECTION: {
        id: 'rejection',
        name: 'Rejection',
        type: 'creature',
        baseStats: {
            attack: 6,
            defense: 10
        },
        description: 'Hard pill to swallow',
        color: 0xFF6B35,
        imageUrl: 'https://rosebud.ai/assets/creature_rejection.png?RMMh'
    },
    ACCEPTANCE: {
        id: 'acceptance',
        name: 'Acceptance',
        type: 'creature',
        baseStats: {
            attack: 1,
            defense: 1
        },
        description: 'Easy to embrace',
        color: 0x66DD44,
        imageUrl: 'https://rosebud.ai/assets/creature_acceptance.png?bPnl'
    }
};

// Element cards that modify creatures (effects to be added later)
export const ELEMENT_CARDS = {
    FIRE: {
        id: 'fire',
        name: 'Fire',
        type: 'element',
        effect: 'Burn effect (coming soon)',
        color: 0xFF4500,
        description: 'Blazing power',
        imageUrl: 'https://rosebud.ai/assets/element_fire.png?5u2m'
    },
    WATER: {
        id: 'water',
        name: 'Water',
        type: 'element',
        effect: 'Flow effect (coming soon)',
        color: 0x1E90FF,
        description: 'Flowing adaptability',
        imageUrl: 'https://rosebud.ai/assets/element_water.png?SATX'
    },
    STONE: {
        id: 'stone',
        name: 'Stone',
        type: 'element',
        effect: 'Fortify effect (coming soon)',
        color: 0x808080,
        description: 'Solid defense',
        imageUrl: 'https://rosebud.ai/assets/element_stone.png?H7ZH'
    },
    WOOD: {
        id: 'wood',
        name: 'Wood',
        type: 'element',
        effect: 'Growth effect (coming soon)',
        color: 0xE87722,
        description: 'Natural growth',
        imageUrl: 'https://rosebud.ai/assets/element_wood.png?QosK'
    }
};

// Attack modifier cards
export const ATTACK_MODIFIER_CARDS = {
    OVEN: {
        id: 'oven',
        name: 'Oven Hand Trap',
        type: 'attack_modifier',
        modifier: 6,
        effect: '+6',
        flavorText: 'Hot and ready to strike',
        color: 0xCC2244,
        imageUrl: 'https://rosebud.ai/assets/attack_modifier_oven.png?TfTv'
    },
    THE_BOBA_BOYS: {
        id: 'the_boba_boys',
        name: 'The Boba Boys',
        type: 'attack_modifier',
        modifier: 7,
        effect: '+7',
        flavorText: 'Tapioca power surge',
        color: 0xCC2244,
        imageUrl: 'https://rosebud.ai/assets/attack_modifier_the_boba_boys.png?9f5F'
    },
    VACUUM_CLEANER: {
        id: 'vacuum_cleaner',
        name: 'Vacuum Cleaner',
        type: 'attack_modifier',
        modifier: 3,
        effect: '+3',
        flavorText: 'Sucks up the competition',
        color: 0xCC2244,
        imageUrl: 'https://rosebud.ai/assets/attack_modifier_vacumn_cleaner.png?Sigk'
    }
};

// Healing cards
export const HEALING_CARDS = {
    BEAR_BUT_NICE: {
        id: 'bear_but_nice',
        name: 'Bear But Nice',
        type: 'healing',
        healing: 6,
        effect: '+6',
        flavorText: 'A warm embrace of recovery',
        color: 0x22DD88,
        imageUrl: 'https://rosebud.ai/assets/healing_bear_but_nice.png?Hquh'
    },
    LARRY: {
        id: 'larry',
        name: 'Larry',
        type: 'healing',
        healing: 3,
        effect: '+3',
        flavorText: 'Just a little pick-me-up',
        color: 0x22DD88,
        imageUrl: 'https://rosebud.ai/assets/healing_larry.png?6u1c'
    }
};

// Defense modifier cards
export const DEFENSE_MODIFIER_CARDS = {
    FRIDGE: {
        id: 'fridge',
        name: 'Fridge Flinger',
        type: 'defense_modifier',
        modifier: 5,
        effect: '+5',
        flavorText: 'Keep your cool under pressure',
        color: 0x9933CC,
        imageUrl: 'https://rosebud.ai/assets/defense_modifier_fridge.png?3FdG'
    },
    FRIDGE_BOUND_DRAWING: {
        id: 'fridge_bound_drawing',
        name: 'Fridge Bound',
        type: 'defense_modifier',
        modifier: 2,
        effect: '+2',
        flavorText: 'Magnetic personality',
        color: 0x9933CC,
        imageUrl: 'https://rosebud.ai/assets/defense_modifier_fridge-bound_drawing.png?Jm74'
    },
    LINT_ROLLER: {
        id: 'lint_roller',
        name: 'Lint Roller',
        type: 'defense_modifier',
        modifier: 7,
        effect: '+7',
        flavorText: 'Rolls with the punches',
        color: 0x9933CC,
        imageUrl: 'https://rosebud.ai/assets/defense_modifier_lint_roller.png?NX2e'
    },
    POTATO_CHIP_INTIMIDATE: {
        id: 'potato_chip_intimidate',
        name: 'Intimitato',
        type: 'defense_modifier',
        modifier: 4,
        effect: '+4',
        flavorText: 'Crispy and intimidating',
        color: 0x9933CC,
        imageUrl: 'https://rosebud.ai/assets/defense_modifier_potato_chip_intimidate.png?2rUt'
    }
};

// Enemy data for battles
export const ENEMIES = [
    { ...CREATURE_CARDS.PAINGUIN, level: 1 },
    { ...CREATURE_CARDS.BICOSIS, level: 1 },
    { ...CREATURE_CARDS.SHOUTOUT, level: 1 }
];