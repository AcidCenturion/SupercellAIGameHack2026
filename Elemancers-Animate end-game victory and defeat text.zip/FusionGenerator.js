// Pre-generated Fusion Asset Lookup
export class FusionGenerator {
    // Pre-generated fusion images lookup table
    // All 24 creature + element combinations (6 creatures × 4 elements)
    static fusionAssets = {
        // Blazing Scarf fusions
        'blazing_scarf_fire': 'https://rosebud.ai/assets/fusion_blazing_scarf_fire.webp?zrxe',
        'blazing_scarf_water': 'https://rosebud.ai/assets/fusion_blazing_scarf_water.webp?p40K',
        'blazing_scarf_stone': 'https://rosebud.ai/assets/fusion_blazing_scarf_stone.webp?cSWW',
        'blazing_scarf_wood': 'https://rosebud.ai/assets/fusion_blazing_scarf_wood.webp?doth',
        
        // Planted Pot fusions
        'planted_pot_fire': 'https://rosebud.ai/assets/fusion_planted_pot_fire.webp?JxF4',
        'planted_pot_water': 'https://rosebud.ai/assets/fusion_planted_pot_water.webp?RMHJ',
        'planted_pot_stone': 'https://rosebud.ai/assets/fusion_planted_pot_stone.webp?3VnK',
        'planted_pot_wood': 'https://rosebud.ai/assets/fusion_planted_pot_wood.webp?4M0d',
        
        // Rock Gem fusions
        'rock_gem_fire': 'https://rosebud.ai/assets/fusion_rock_gem_fire.webp?sC0a',
        'rock_gem_water': 'https://rosebud.ai/assets/fusion_rock_gem_water.webp?OBZV',
        'rock_gem_stone': 'https://rosebud.ai/assets/fusion_rock_gem_stone.webp?LH68',
        'rock_gem_wood': 'https://rosebud.ai/assets/fusion_rock_gem_wood.webp?CV1e',
        
        // Painguin fusions
        'painguin_fire': 'https://rosebud.ai/assets/fusion_painguin_fire.webp?hIXP',
        'painguin_water': 'https://rosebud.ai/assets/fusion_painguin_water.webp?OlbF',
        'painguin_stone': 'https://rosebud.ai/assets/fusion_painguin_stone.webp?Vtrj',
        'painguin_wood': 'https://rosebud.ai/assets/fusion_painguin_wood.webp?UW94',
        
        // Bicosis fusions
        'bicosis_fire': 'https://rosebud.ai/assets/fusion_bicosis_fire.webp?K24g',
        'bicosis_water': 'https://rosebud.ai/assets/fusion_bicosis_water.webp?KkfS',
        'bicosis_stone': 'https://rosebud.ai/assets/fusion_bicosis_stone.webp?vMdX',
        'bicosis_wood': 'https://rosebud.ai/assets/fusion_bicosis_wood.webp?G7pT',
        
        // Shoutout fusions
        'shoutout_fire': 'https://rosebud.ai/assets/fusion_shoutout_fire.webp?zjru',
        'shoutout_water': 'https://rosebud.ai/assets/fusion_shoutout_water.webp?KZW8',
        'shoutout_stone': 'https://rosebud.ai/assets/fusion_shoutout_stone.webp?BFSW',
        'shoutout_wood': 'https://rosebud.ai/assets/fusion_shoutout_wood.webp?pqwt',
        
        // Rejection fusions
        'rejection_fire': 'https://rosebud.ai/assets/fusion_rejection_fire.webp?XoV2',
        'rejection_water': 'https://rosebud.ai/assets/fusion_rejection_water.webp?Ioy2',
        'rejection_stone': 'https://rosebud.ai/assets/fusion_rejection_stone.webp?zSds',
        'rejection_wood': 'https://rosebud.ai/assets/fusion_rejection_wood.webp?BwF3',
        
        // Acceptance fusions
        'acceptance_fire': 'https://rosebud.ai/assets/fusion_acceptance_fire.webp?CuRR',
        'acceptance_water': 'https://rosebud.ai/assets/fusion_acceptance_water.webp?1m3X',
        'acceptance_stone': 'https://rosebud.ai/assets/fusion_acceptance_stone.webp?eThB',
        'acceptance_wood': 'https://rosebud.ai/assets/fusion_acceptance_wood.webp?PwQT'
    };
    
    static async generateFusionImage(creature, element, modifiers) {
        // Check if creature has an imageUrl (only creatures with custom art get fusions)
        if (!creature.imageUrl) {
            return null;
        }
        
        // Only handle element fusions (modifiers alone don't have pre-generated art)
        if (!element) {
            return null;
        }
        
        // Build lookup key from creature ID and element ID
        const creatureId = creature.id; // e.g., 'blazing_scarf'
        const elementId = element.id; // e.g., 'fire'
        const fusionKey = `${creatureId}_${elementId}`;
        
        console.log('[FusionGenerator] Looking up fusion:', fusionKey);
        
        const fusionUrl = this.fusionAssets[fusionKey];
        
        if (fusionUrl) {
            console.log('[FusionGenerator] Found pre-generated fusion:', fusionUrl);
            return fusionUrl;
        } else {
            console.warn('[FusionGenerator] No fusion found for:', fusionKey);
            console.warn('[FusionGenerator] Available keys:', Object.keys(this.fusionAssets));
            return null;
        }
    }
    
    // Check if a creature should trigger fusion generation
    static shouldGenerateFusion(creature, element, modifiers) {
        // Only generate for creatures with uploaded images
        if (!creature.imageUrl) {
            return false;
        }
        
        // Only generate if there's an element (modifiers alone don't have pre-generated art)
        return !!element;
    }
}
