import * as Tone from 'tone';

class SoundManager {
    constructor() {
        this.initialized = false;
    }
    
    async init() {
        if (this.initialized) return;
        await Tone.start();
        this.initialized = true;
    }
    
    playClick() {
        const synth = new Tone.Synth({
            oscillator: { type: 'sine' },
            envelope: { attack: 0.001, decay: 0.1, sustain: 0, release: 0.1 }
        }).toDestination();
        synth.triggerAttackRelease('C5', '0.05');
        // Dispose after sound finishes
        setTimeout(() => synth.dispose(), 200);
    }
    
    playCardSelect() {
        const synth = new Tone.Synth({
            oscillator: { type: 'triangle' },
            envelope: { attack: 0.005, decay: 0.2, sustain: 0, release: 0.2 }
        }).toDestination();
        synth.triggerAttackRelease('E5', '0.1');
        // Dispose after sound finishes
        setTimeout(() => synth.dispose(), 500);
    }
    
    playFusion() {
        const synth = new Tone.PolySynth(Tone.Synth).toDestination();
        const now = Tone.now();
        synth.triggerAttackRelease(['C4', 'E4', 'G4', 'C5'], '0.5', now);
        // Dispose after sound finishes
        setTimeout(() => synth.dispose(), 1000);
    }
    
    playAttack() {
        const synth = new Tone.MembraneSynth().toDestination();
        synth.triggerAttackRelease('C2', '0.1');
        // Dispose after sound finishes
        setTimeout(() => synth.dispose(), 300);
    }
    
    playVictory() {
        const synth = new Tone.PolySynth(Tone.Synth).toDestination();
        const now = Tone.now();
        synth.triggerAttackRelease('C5', '0.2', now);
        synth.triggerAttackRelease('E5', '0.2', now + 0.15);
        synth.triggerAttackRelease('G5', '0.3', now + 0.3);
        synth.triggerAttackRelease('C6', '0.5', now + 0.45);
        // Dispose after sound finishes (longest note + release time)
        setTimeout(() => synth.dispose(), 1500);
    }
    
    playDefeat() {
        const synth = new Tone.Synth({
            oscillator: { type: 'sawtooth' },
            envelope: { attack: 0.01, decay: 0.5, sustain: 0, release: 0.5 }
        }).toDestination();
        const now = Tone.now();
        synth.triggerAttackRelease('G3', '0.3', now);
        synth.triggerAttackRelease('F3', '0.3', now + 0.2);
        synth.triggerAttackRelease('D3', '0.5', now + 0.4);
        // Dispose after sound finishes (longest note + release time)
        setTimeout(() => synth.dispose(), 1500);
    }
    
    playHeal() {
        const synth = new Tone.PolySynth(Tone.Synth, {
            oscillator: { type: 'sine' },
            envelope: { attack: 0.2, decay: 0.1, sustain: 0.5, release: 1 },
            volume: -15 // Significantly reduce volume to prevent clipping distortion
        }).toDestination();
        const now = Tone.now();
        // Softer, lower register ascending major chord (G major)
        synth.triggerAttackRelease('G4', '0.5', now);
        synth.triggerAttackRelease('B4', '0.5', now + 0.15);
        synth.triggerAttackRelease('D5', '0.5', now + 0.3);
        synth.triggerAttackRelease('G5', '0.8', now + 0.45);
        // Dispose after sound finishes (longest note + release time)
        setTimeout(() => synth.dispose(), 2500);
    }
    
    playSlash() {
        // Low-end heavy thud impact
        const impact = new Tone.MembraneSynth({
            pitchDecay: 0.05,
            octaves: 4,
            oscillator: { type: 'sine' },
            envelope: { attack: 0.001, decay: 0.2, sustain: 0, release: 0.1 },
            volume: -5
        }).toDestination();
        
        // High-end wind slash/noise
        const noise = new Tone.NoiseSynth({
            noise: { type: 'white' },
            envelope: { attack: 0.005, decay: 0.2, sustain: 0, release: 0.2 },
            volume: -8
        }).toDestination();
        
        const filter = new Tone.AutoFilter({
            frequency: '4n',
            baseFrequency: 400,
            octaves: 5
        }).toDestination().start();
        
        noise.connect(filter);
        
        const now = Tone.now();
        impact.triggerAttackRelease('G1', '8n', now);
        noise.triggerAttackRelease('8n', now);
        
        // Dispose after sound finishes
        setTimeout(() => {
            impact.dispose();
            noise.dispose();
            filter.dispose();
        }, 500);
    }
    
    playBlock() {
        // Metallic "clang" using two high-pitched notes with a bite
        const synth = new Tone.PolySynth(Tone.Synth, {
            oscillator: { type: 'sine' },
            envelope: { attack: 0.001, decay: 0.15, sustain: 0, release: 0.15 },
            volume: -8
        }).toDestination();
        
        const now = Tone.now();
        // Slightly detuned pair for metallic resonance
        synth.triggerAttackRelease(['C7', 'C#7'], '16n', now);
        
        // Add a tiny bit of noise for the "hit" impact
        const click = new Tone.NoiseSynth({
            envelope: { attack: 0.001, decay: 0.02, sustain: 0, release: 0.02 },
            volume: -10
        }).toDestination();
        click.triggerAttackRelease('32n', now);
        
        // Dispose after sound finishes
        setTimeout(() => {
            synth.dispose();
            click.dispose();
        }, 400);
    }
    
    playError() {
        const synth = new Tone.Synth({
            oscillator: { type: 'sawtooth' },
            envelope: { attack: 0.001, decay: 0.1, sustain: 0, release: 0.1 },
            volume: -12
        }).toDestination();
        // Short low buzz
        synth.triggerAttackRelease('G2', '0.1');
        // Dispose after sound finishes
        setTimeout(() => synth.dispose(), 300);
    }
}

export const soundManager = new SoundManager();
