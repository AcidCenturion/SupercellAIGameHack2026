import Phaser from 'phaser';
import { gameState } from './GameState.js';
import Card from './Card.js';
import { soundManager } from './SoundManager.js';

export default class CombineScene extends Phaser.Scene {
    constructor() {
        super({ key: 'CombineScene' });
    }
    
    create() {
        const { width, height } = this.cameras.main;
        
        // Title
        const title = this.add.text(width / 2, 80, 'COMBINE CARDS', {
            fontSize: '48px',
            color: '#ffcc00',
            fontFamily: 'Press Start 2P'
        });
        title.setOrigin(0.5);
        
        const instruction = this.add.text(width / 2, 160, 
            'Click a Creature + Element to fuse them',
            {
                fontSize: '24px',
                color: '#ffffff',
                fontFamily: 'Arial'
            }
        );
        instruction.setOrigin(0.5);
        
        this.selectedCreature = null;
        this.selectedElement = null;
        this.creatureCards = [];
        this.elementCards = [];
        this.fusedCards = [];
        
        // Display creatures
        const creatureLabel = this.add.text(360, 280, 'CREATURES:', {
            fontSize: '28px',
            color: '#ff8844',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        });
        
        gameState.baseCreatures.forEach((creature, index) => {
            const card = new Card(this, 360, 400 + index * 360, creature);
            card.setInteractive();
            card.cardData.stats = { ...creature.baseStats };
            
            card.on('pointerdown', () => {
                // Deselect all creatures
                this.creatureCards.forEach(c => c.highlight(false));
                // Select this one
                this.selectedCreature = card;
                card.highlight(true);
                this.checkCombination();
            });
            
            this.creatureCards.push(card);
        });
        
        // Display elements
        const elementLabel = this.add.text(720, 280, 'ELEMENTS:', {
            fontSize: '28px',
            color: '#44ccff',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        });
        
        gameState.baseElements.forEach((element, index) => {
            const card = new Card(this, 720, 400 + index * 360, element);
            card.setInteractive();
            
            card.on('pointerdown', () => {
                // Deselect all elements
                this.elementCards.forEach(c => c.highlight(false));
                // Select this one
                this.selectedElement = card;
                card.highlight(true);
                this.checkCombination();
            });
            
            this.elementCards.push(card);
        });
        
        // Fusion area
        const fusionLabel = this.add.text(1300, 280, 'FUSED CARDS:', {
            fontSize: '28px',
            color: '#00ff00',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        });
        
        this.fusionArea = this.add.text(1300, 360, 
            'Select Creature\n+ Element',
            {
                fontSize: '22px',
                color: '#888888',
                fontFamily: 'Arial',
                align: 'center'
            }
        );
        
        // Fuse button
        this.fuseButton = this.add.rectangle(width / 2, 540, 350, 80, 0x666666);
        this.fuseButton.setStrokeStyle(4, 0xffffff);
        this.fuseButtonText = this.add.text(width / 2, 540, 'SELECT BOTH', {
            fontSize: '24px',
            color: '#888888',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        });
        this.fuseButtonText.setOrigin(0.5);
        
        // Continue button (appears after fusing)
        this.continueButton = this.add.rectangle(width / 2, 980, 400, 70, 0x666666);
        this.continueButton.setStrokeStyle(4, 0xffffff);
        this.continueButton.setAlpha(0);
        
        this.continueText = this.add.text(width / 2, 980, 'BATTLE!', {
            fontSize: '28px',
            color: '#ffffff',
            fontFamily: 'Press Start 2P'
        });
        this.continueText.setOrigin(0.5);
        this.continueText.setAlpha(0);
    }
    
    checkCombination() {
        if (this.selectedCreature && this.selectedElement) {
            this.fuseButton.setFillStyle(0xff00ff);
            this.fuseButton.setInteractive({ useHandCursor: true });
            this.fuseButtonText.setText('FUSE!');
            this.fuseButtonText.setColor('#ffffff');
            
            this.fuseButton.removeAllListeners();
            this.fuseButton.on('pointerdown', () => {
                this.performFusion();
            });
        } else {
            this.fuseButton.setFillStyle(0x666666);
            this.fuseButton.disableInteractive();
            this.fuseButtonText.setText('SELECT BOTH');
            this.fuseButtonText.setColor('#888888');
        }
    }
    
    async performFusion() {
        if (!this.selectedCreature || !this.selectedElement) return;
        
        soundManager.playFusion();
        
        const creature = this.selectedCreature.cardData;
        const element = this.selectedElement.cardData;
        
        // Disable button during fusion
        this.fuseButton.disableInteractive();
        this.fuseButtonText.setText('FUSING...');
        
        // Calculate fused stats
        const fusedStats = {
            attack: Math.floor(creature.baseStats.attack * element.modifier.attack),
            health: Math.floor(creature.baseStats.health * element.modifier.health),
            speed: Math.floor(creature.baseStats.speed * element.modifier.speed)
        };
        
        // Create combined card data
        const combinedCard = {
            id: `${creature.id}_${element.id}`,
            name: `${element.name} ${creature.name}`,
            type: 'fused',
            stats: fusedStats,
            element: element.name,
            effect: element.effect,
            color: element.color,
            description: `${creature.description} + ${element.description}`,
            baseCreature: creature,
            baseElement: element
        };
        
        // Generate AI art for the fused card
        try {
            const { width, height } = this.cameras.main;
            
            const prompt = `A fantasy ${element.name.toLowerCase()} ${creature.name.toLowerCase()} creature, 
                digital card game art, ${element.description}, ${creature.description}, 
                vibrant colors, magical aura, frontal view, detailed illustration, 
                trading card game style, centered composition`;
            
            const statusText = this.add.text(width / 2 + 200, 600, 
                'Generating fusion art...',
                {
                    fontSize: '16px',
                    color: '#ffcc00',
                    fontFamily: 'Arial'
                }
            );
            
            // Use ImageGenerator to create the combined card art
            const result = await window.generateImages([{
                prompt: prompt,
                name: `${creature.id}_${element.id}`,
                n: 1
            }]);
            
            if (result && result[0] && result[0].url) {
                combinedCard.imageUrl = result[0].url;
            }
            
            statusText.destroy();
        } catch (error) {
            console.error('Failed to generate fusion art:', error);
        }
        
        // Add to game state
        gameState.addCombinedCard(combinedCard);
        this.fusedCards.push(combinedCard);
        
        // Display the fused card
        this.displayFusedCards();
        
        // Remove used cards
        this.selectedCreature.destroy();
        this.selectedElement.destroy();
        this.creatureCards = this.creatureCards.filter(c => c !== this.selectedCreature);
        this.elementCards = this.elementCards.filter(c => c !== this.selectedElement);
        
        this.selectedCreature = null;
        this.selectedElement = null;
        
        // Reset button
        this.fuseButton.setFillStyle(0x666666);
        this.fuseButtonText.setText('SELECT BOTH');
        this.fuseButtonText.setColor('#888888');
        
        // Check if we can continue
        if (this.creatureCards.length === 0 || this.elementCards.length === 0) {
            this.showContinueButton();
        }
    }
    
    displayFusedCards() {
        // Clear previous display
        this.fusionArea.destroy();
        
        // Display all fused cards
        const startY = 400;
        this.fusedCards.forEach((fusedCard, index) => {
            const card = new Card(this, 1500, startY + index * 360, fusedCard, fusedCard.imageUrl);
        });
    }
    
    showContinueButton() {
        this.continueButton.setFillStyle(0x00aa00);
        this.continueButton.setInteractive({ useHandCursor: true });
        this.continueButton.setAlpha(1);
        this.continueText.setAlpha(1);
        
        this.continueButton.on('pointerdown', () => {
            soundManager.playClick();
            this.scene.start('BattleScene');
        });
    }
}
