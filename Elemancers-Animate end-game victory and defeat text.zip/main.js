import Phaser from 'phaser';
import MenuScene from './MenuScene.js';
import DraftScene from './DraftScene.js';
import BattleScene from './BattleScene.js';
import VictoryScene from './VictoryScene.js';
import GameOverScene from './GameOverScene.js';

const config = {
    type: Phaser.AUTO,
    width: 1920,
    height: 1080,
    backgroundColor: '#1a0033',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
    scene: [DraftScene, BattleScene, VictoryScene, GameOverScene, MenuScene]
};

const game = new Phaser.Game(config);
