import Phaser from 'phaser';
import { gameState } from './GameState.js';

export default class GameOverScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameOverScene' });
    }
    
    create() {
        const { width, height } = this.cameras.main;
        
        // Game over text
        const title = this.add.text(width / 2, 300, 'RUN FAILED', {
            fontSize: '72px',
            color: '#ff0000',
            fontFamily: 'Press Start 2P',
            stroke: '#000000',
            strokeThickness: 10
        });
        title.setOrigin(0.5);
        
        // Stats
        const battlesWon = gameState.currentBattle;
        const stats = this.add.text(width / 2, 500, 
            `Battles Won: ${battlesWon} / ${gameState.totalBattles}\n\nTotal Runs Lost: ${gameState.losses}`,
            {
                fontSize: '32px',
                color: '#ffffff',
                fontFamily: 'Arial',
                align: 'center',
                lineSpacing: 15
            }
        );
        stats.setOrigin(0.5);
        
        // Encouragement
        const message = this.add.text(width / 2, 650, 
            'Try different creature and element combinations!',
            {
                fontSize: '24px',
                color: '#aaaaaa',
                fontFamily: 'Arial',
                align: 'center'
            }
        );
        message.setOrigin(0.5);
        
        // Retry button
        const retryButton = this.add.rectangle(width / 2 - 230, 850, 350, 70, 0x00aa00);
        retryButton.setStrokeStyle(4, 0xffffff);
        retryButton.setInteractive({ useHandCursor: true });
        
        const retryText = this.add.text(width / 2 - 230, 850, 'TRY AGAIN', {
            fontSize: '28px',
            color: '#ffffff',
            fontFamily: 'Press Start 2P'
        });
        retryText.setOrigin(0.5);
        
        retryButton.on('pointerover', () => {
            retryButton.setFillStyle(0x00ff00);
        });
        
        retryButton.on('pointerout', () => {
            retryButton.setFillStyle(0x00aa00);
        });
        
        retryButton.on('pointerdown', () => {
            gameState.reset();
            this.scene.start('DraftScene');
        });
        
        // Menu button
        const menuButton = this.add.rectangle(width / 2 + 230, 850, 350, 70, 0x0066cc);
        menuButton.setStrokeStyle(4, 0xffffff);
        menuButton.setInteractive({ useHandCursor: true });
        
        const menuText = this.add.text(width / 2 + 230, 850, 'MAIN MENU', {
            fontSize: '28px',
            color: '#ffffff',
            fontFamily: 'Press Start 2P'
        });
        menuText.setOrigin(0.5);
        
        menuButton.on('pointerover', () => {
            menuButton.setFillStyle(0x0088ff);
        });
        
        menuButton.on('pointerout', () => {
            menuButton.setFillStyle(0x0066cc);
        });
        
        menuButton.on('pointerdown', () => {
            this.scene.start('MenuScene');
        });
    }
}
